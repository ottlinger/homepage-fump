package com.fump;

/**
*  @author Markus und Philipp
*  @version $Id: KopierenEvent.java,v 1.1 2001/07/14 23:28:13 ottlinge Exp $
*/

import com.fump.*;
import javax.swing.event.*;
import java.util.*;
import java.io.*;

public class KopierenEvent extends EventObject {
	private TreePath vonPfad;
	private TreePath inPfad;
		
	public KopierenEvent(Object source, TreePath aktPfad,TreePath inPfad) {
		super(source);
		this.vonPfad=vonPfad;
		this.inPfad=inPfad;
	} // end of Konstruktor

	public String gibAktPfad() 	{
		return this.vonPfad;
	} // end of gibAktPfad
	
	public String gibAktPfad() 	{
		return this.vonPfad;
	} // end of gibAktPfad
	
	public String toString() {
		return "KopierenFenster fertig";
	} // end of toString
} // end of class
