package com.fump;
/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: KeineOrdnerDa.java,v 1.1 2001/07/04 13:52:51 ottlinge Exp $
 */

    /** KeineOrdnerDa-Exception
    */
public class KeineOrdnerDa extends Exception { }
