package com.fump;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
*@author B. Hentrich, J. K. Olesen
*@version $id$
*/
/**
*Stellt die graphische Benutzeroberfl�che f�r die Benutzerverwaltungsfunktionen
*der Klasse BenutzerContainer her.
*/
public class BenutzerGui
{
	private final static JLabel comment = new JLabel("");
	private static JDialog dialogtmp = new JDialog();
	
	private final static JDialog dialog = dialogtmp;
	private final static JComboBox allUsers = new JComboBox(BenutzerContainer.getallUsersModel());
	public BenutzerGui(JFrame parent)
	{
		dialogtmp = new JDialog(parent,"FUMP - Benutzerverwaltung",true);
		dialog.setTitle("FUMP - Benutzerverwaltung        F1=Hilfe");
		dialog.setResizable(false);
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		dialog.setLocation((int)(size.width*0.35),(int)(size.height*0.35));
		dialog.setSize(400,310);
		dialog.getContentPane().removeAll();
	   	if (BenutzerContainer.getallUsersModel().getSize()==0)dialog.getContentPane().add(addGui());
		else dialog.getContentPane().add(selectGui());
		dialog.setLocation(300,250);
		dialog.validate();
		dialog.setVisible(true);
		
		
		dialog.addWindowListener(new WindowAdapter()	
		{
			
			public void windowOpened(WindowEvent op)
			{
				allUsers.grabFocus();
			}
			public void windowClosing(WindowEvent e)
			{
	    			if (BenutzerContainer.isStart()) System.exit(0);
	    			else dialog.dispose();
			}
	    });
	    dialog.addKeyListener(new KeyAdapter()
	    {
	    	public void keyPressed(KeyEvent e)
		{
			if (e.getKeyCode()==KeyEvent.VK_F1)
			{
				FUMP.hilfe.kontext_hilfe("Benutzer");
				System.out.println("Hilfe aufgerufen");
			}
		}
		});
	}
	
	public static JPanel selectGui()
	{
	//title
		JLabel title = new JLabel((Icon) new ImageIcon(FUMP.class.getResource("bilder/Benutzerverwaltung.gif")));
		JPanel titleContainer = new JPanel(new FlowLayout());
		titleContainer.setPreferredSize(new Dimension(320,60));
		titleContainer.add(title);
	//comment
		comment.setText("");
		comment.setForeground(Color.red);
		comment.setHorizontalAlignment(JLabel.CENTER);
		JPanel commentContainer = new JPanel(new FlowLayout());
		commentContainer.setPreferredSize(new Dimension(320,30));
		commentContainer.add(comment);
	//title & head Container/Layout
		JPanel head = new JPanel(new BorderLayout());
		head.add("Center",title);
		head.add("South",commentContainer);
	//Benutzer Dropdownmen�
		allUsers.setPreferredSize(new Dimension(150,30));
		allUsers.validate();
		allUsers.setSelectedIndex(0);
		if (!BenutzerContainer.isStart())allUsers.setSelectedItem(BenutzerContainer.getBenutzer().getName()); 
		JPanel usersContainer = new JPanel(new FlowLayout());
		usersContainer.add(allUsers);
		
	//Passwortfeld
		JLabel passwordLabel = new JLabel("Password eingeben:");
		passwordLabel.setPreferredSize(new Dimension(150,30));
		JPanel passwordLabelContainer = new JPanel(new FlowLayout());
		passwordLabelContainer.add(passwordLabel);
		final JPasswordField password = new JPasswordField();
		password.setText("");
		password.setPreferredSize(new Dimension(150,30));
		JPanel passwordContainer = new JPanel(new FlowLayout());
		passwordContainer.add(password);
	//Buttonleiste links
	//Button neu 
		JButton neu = new JButton("Neu");
		neu.setMnemonic('n');
		neu.setPreferredSize(new Dimension(120,30));
		JPanel neuContainer = new JPanel(new FlowLayout());
		neuContainer.add(neu);
		ActionListener al_neu = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
	   			comment.setText("");
	   			dialog.getContentPane().removeAll();
	   			dialog.getContentPane().add(addGui());
	   			dialog.validate();
	 		}
		};
		neu.addActionListener(al_neu);
	//Button bearbeiten
		JButton bearbeiten = new JButton("Bearbeiten");
		bearbeiten.setMnemonic('b');
		bearbeiten.setPreferredSize(new Dimension(120,30));
		JPanel bearbeitenContainer = new JPanel(new FlowLayout());
		bearbeitenContainer.add(bearbeiten);
		ActionListener al_bearbeiten = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
	   			if (BenutzerContainer.accessBenutzer((String) allUsers.getSelectedItem(),BenutzerContainer.ToString(password.getPassword())))
	   			{
	   				dialog.getContentPane().removeAll();
	   				dialog.getContentPane().add(changeGui());
	   				dialog.validate();
	   			}
	   			else 
	   			{
	   				comment.setText("Das eingegebene Password ist falsch!");
	   				password.setText("");
	   			}
	   		}
		};
		bearbeiten.addActionListener(al_bearbeiten);
	//Button  l�schen
		JButton l�schen = new JButton("L�schen");
		l�schen.setMnemonic('l');
		l�schen.setPreferredSize(new Dimension(120,30));
		JPanel l�schenContainer = new JPanel(new FlowLayout());
		l�schenContainer.add(l�schen);
		ActionListener al_l�schen = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
	   			try
	   			{
	   				int n = JOptionPane.showConfirmDialog(
	            			dialog, "Wollen Sie den Benutzer "+(String) allUsers.getSelectedItem()+" wirklich l�schen?",
	                        "Frage",
	                        JOptionPane.YES_NO_OPTION);
		   			if (n == JOptionPane.YES_OPTION)
		   			{
	   					comment.setText("Benutzer: "+(String) allUsers.getSelectedItem()+" wurde gel�scht"); 
	   					BenutzerContainer.delBenutzer((String) allUsers.getSelectedItem(),BenutzerContainer.ToString(password.getPassword()));
	   					allUsers.validate();
	   				}
	   				else comment.setText("");
	   				password.setText("");
	   			}
	   			catch (InputException wpe) {comment.setText(wpe.getFehlerMeldung());}
	   			//
	   			catch (IOException ioe)	{comment.setText("Fehler beim schreibender Datei users.conf");}
	   			if (BenutzerContainer.getallUsersModel().getSize()==0)
	   			{
	   				comment.setText("");
	   				dialog.getContentPane().removeAll();
	   				dialog.getContentPane().add(addGui());
	   				dialog.validate();
	   			}
	   		}	
	   	};
		l�schen.addActionListener(al_l�schen);
	//Buttonleiste unten
	//Button w�hlen
		JButton w�hlen = new JButton("Benutzer wechseln");
		w�hlen.setMnemonic('w');
		if (BenutzerContainer.isStart()) 
		{
			w�hlen.setText("OK");
			w�hlen.setMnemonic('o');			
		}
		w�hlen.setPreferredSize(new Dimension(180,30));
		JPanel w�hlenContainer = new JPanel(new FlowLayout());
		w�hlenContainer.add(w�hlen);
		ActionListener al_w�hlen = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
	   			try
	   			{
	   				BenutzerContainer.setBenutzer((String) allUsers.getSelectedItem(),BenutzerContainer.ToString(password.getPassword()));
	   				dialog.dispose();
	   			}
	   			catch (InputException wpe)
	   			{
	   				password.setText("");
	   				comment.setText(wpe.getFehlerMeldung());
	   			}
			}
		};
		w�hlen.addActionListener(al_w�hlen);
	//Schlie�en
		JButton schlie�en = new JButton("Schlie�en");
		schlie�en.setMnemonic('c');
		if (BenutzerContainer.isStart()) schlie�en.setText("Abbrechen");
		schlie�en.setPreferredSize(new Dimension(180,30));
		JPanel schlie�enContainer = new JPanel(new FlowLayout());
		schlie�enContainer.add(schlie�en);
		ActionListener al_schlie�en = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
		   		if (BenutzerContainer.isStart())
		   		{
		   			int n = JOptionPane.showConfirmDialog(
	            			dialog, "Fump l��t sich nicht ohne Benutzer starten! Wollen sie Fump\n wirklich beenden?",
	                        "Wahrnung",
	                        JOptionPane.YES_NO_OPTION);
		   			if (n == JOptionPane.YES_OPTION) System.exit(0);
		   		}
		   		else dialog.dispose();
			}
		};
		schlie�en.addActionListener(al_schlie�en);
	//Layout Buttonleiste unten		
		JPanel sButtonContainer = new JPanel(new GridLayout(1,2));
		sButtonContainer.add(w�hlenContainer);
		sButtonContainer.add(schlie�enContainer);
	//Keylistener f�r OK
		dialog.addKeyListener(new KeyAdapter()
	    {
	    	public void keyPressed(KeyEvent e)
		{
			if (e.getKeyCode()==KeyEvent.VK_ENTER)
			{
				try
	   			{
	   				BenutzerContainer.setBenutzer((String) allUsers.getSelectedItem(),BenutzerContainer.ToString(password.getPassword()));
	   				dialog.dispose();
	   			}
	   			catch (InputException wpe)
	   			{
	   				password.setText("");
	   				comment.setText(wpe.getFehlerMeldung());
	   			}
			}
		}
		});
	
	
	//Layout gesamt
		JPanel centerContainer = new JPanel(new GridLayout(3,2));
		centerContainer.add(neuContainer);
		centerContainer.add(usersContainer);
		centerContainer.add(bearbeitenContainer);
		centerContainer.add(passwordLabelContainer);
		centerContainer.add(l�schenContainer);
		centerContainer.add(passwordContainer);
		centerContainer.setPreferredSize(new Dimension(380,110));
		JPanel center1Container = new JPanel(new FlowLayout());
		center1Container.add(centerContainer);
		JPanel content = new JPanel(new BorderLayout());
		content.setBorder(BorderFactory.createEmptyBorder (10,10,10,10));
		content.add("North",head);
		content.add("Center",center1Container);
		content.add("South",sButtonContainer);
		password.setNextFocusableComponent(w�hlen);
		w�hlen.setNextFocusableComponent(schlie�en);
		schlie�en.setNextFocusableComponent(neu);
		neu.setNextFocusableComponent(bearbeiten);
		bearbeiten.setNextFocusableComponent(l�schen);
		l�schen.setNextFocusableComponent(allUsers);
		allUsers.setNextFocusableComponent(password);
		
		return content;
	}

	public static JPanel addGui()
	{
	//title
		JLabel title = new JLabel((Icon) new ImageIcon(FUMP.class.getResource("bilder/Benutzeranlegen.gif")));
		JPanel titleContainer = new JPanel(new FlowLayout());
		titleContainer.setPreferredSize(new Dimension(320,60));
		titleContainer.add(title);
	//comment
		comment.setText("");
		comment.setForeground(Color.red);
		comment.setHorizontalAlignment(JLabel.CENTER);
		JPanel commentContainer = new JPanel(new FlowLayout());
		commentContainer.setPreferredSize(new Dimension(320,30));
		commentContainer.add(comment);
	//title & comment layout
		JPanel head = new JPanel(new BorderLayout());
		head.add("Center",title);
		head.add("South",commentContainer);
	//Name
		JLabel nameLabel = new JLabel("Benutzername:");
		final JTextField name = new JTextField();
		name.grabFocus();
		name.setPreferredSize(new Dimension(150,25));
		JPanel nameContainer = new JPanel(new FlowLayout());
		nameContainer.add(name);
	//Passwortfeld
		JLabel passwordLabel = new JLabel("Password eingeben:");
		final JPasswordField password = new JPasswordField();
		password.setPreferredSize(new Dimension(150,25));
		JPanel passwordContainer = new JPanel(new FlowLayout());
		passwordContainer.add(password);
	//Passwortfeld wiederholen
		JLabel passwordLabel1 = new JLabel("Password wiederholen:");
		final JPasswordField password1 = new JPasswordField();
		password1.setPreferredSize(new Dimension(150,25));
		JPanel passwordContainer1 = new JPanel(new FlowLayout());
		passwordContainer1.add(password1);
	//Speicherpfad
		JLabel pathLabel = new JLabel("Speicherpfad:");
		final JTextField path = new JTextField(System.getProperty("user.dir"));
		path.setPreferredSize(new Dimension(120,25));
	//Pfad w�hlen Button
		JButton pathSelect = new JButton((Icon) new ImageIcon(FUMP.class.getResource("bilder/Open.gif")));		
		pathSelect.setPreferredSize(new Dimension(25,25));
		ActionListener al_pathSelect = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
		   		JFileChooser chooser = new JFileChooser(path.getText());
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				if (chooser.showDialog(dialog,"Verzeichnis w�hlen")==chooser.APPROVE_OPTION)
				{
					path.setText(chooser.getSelectedFile().toString());
				}
			}
		};
		pathSelect.addActionListener(al_pathSelect);
	//Pfad Layout	
		JPanel pathContainer = new JPanel(new FlowLayout());
		pathContainer.add(path);
		pathContainer.add(pathSelect);
	//Buttonleiste unten
	//anlegen
		JButton anlegen = new JButton("Anlegen");
		anlegen.setMnemonic('o');
		if (BenutzerContainer.isStart()) anlegen.setText("OK");
		anlegen.setPreferredSize(new Dimension(120,30));
		JPanel anlegenContainer = new JPanel(new FlowLayout());
		anlegenContainer.add(anlegen);
		ActionListener al_anlegen = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
	   			try
	   			{
	   				boolean b = BenutzerContainer.isStart();
	   				BenutzerContainer.addBenutzer(name.getText(),BenutzerContainer.ToString(password.getPassword()),BenutzerContainer.ToString(password1.getPassword()),path.getText());
	   				if (b) dialog.dispose();
	   				else
	   				{
	   					comment.setText("Der Benutzer " + name.getText() +" wurde angelegt!");
	   					name.setText("");
	   					password.setText("");
	   					password1.setText("");
	   				}
	   			}
	   			catch (InputException ie)
	   			{
	   				comment.setText(ie.getFehlerMeldung());
	   				if (ie.getFault()<=2)name.setText("");
	   				else
	   				{
	   					password.setText("");
	   					password1.setText("");
	   				}
	   			}
	   			//
	   			catch (IOException ioe)
	   			{
	   				JOptionPane.showMessageDialog(dialog,"Fehler beim Schreiben der Datei users.conf!!!",
		  						      				"Fehler",
                   	            					JOptionPane.ERROR_MESSAGE);	
        		}	
			}
		};
		anlegen.addActionListener(al_anlegen);
	//Abbrechen
		JButton abbrechen = new JButton("Abbrechen");
		abbrechen.setMnemonic('c');
		abbrechen.setPreferredSize(new Dimension(120,30));
		JPanel abbrechenContainer = new JPanel(new FlowLayout());
		abbrechenContainer.add(abbrechen);
		ActionListener al_abbrechen = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
	   			if (BenutzerContainer.getallUsersModel().getSize()==0)
	   			{
		   			int n = JOptionPane.showConfirmDialog(
	            			dialog, "Fump l��t sich nicht ohne Benutzer starten! Wollen sie Fump\n wirklich beenden?",
	                        "Warnung",
	                        JOptionPane.YES_NO_OPTION);
		   			if (n == JOptionPane.YES_OPTION) System.exit(0);
		   		}
		   		else 
		   		{
		   			dialog.getContentPane().removeAll();
	   				dialog.getContentPane().add(selectGui());
	   				dialog.validate();
	   			}
			}
		};
		abbrechen.addActionListener(al_abbrechen);
	//Schlie�en
		JButton schlie�en = new JButton("Schlie�en");
		schlie�en.setMnemonic('s');
		schlie�en.setPreferredSize(new Dimension(120,30));
		JPanel schlie�enContainer = new JPanel(new FlowLayout());
		schlie�enContainer.add(schlie�en);
		ActionListener al_schlie�en = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
	   			try
	   			{
	   				if (!(name.getText().trim().equals("")))
	   				{
	   					int n = JOptionPane.showConfirmDialog(
	            				dialog, "Sie haben den Benutzer noch nicht gespeichert. \n Wollen Sie den Benutzer jetzt speichern?",
	                	        "Wahrnung",
	                   	     JOptionPane.YES_NO_OPTION);
		   				if (n == JOptionPane.YES_OPTION) BenutzerContainer.addBenutzer(name.getText(),BenutzerContainer.ToString(password.getPassword()),BenutzerContainer.ToString(password1.getPassword()),path.getText());
	   				}	
					if (BenutzerContainer.getallUsersModel().getSize()==0)
	   				{
		   				int n = JOptionPane.showConfirmDialog(
	            				dialog, "Fump l��t sich nicht ohne Benutzer starten! Wollen sie Fump\n wirklich beenden?",
	                        	"Warnung",
	                        	JOptionPane.YES_NO_OPTION);
		   				if (n == JOptionPane.YES_OPTION) System.exit(0);
		   			}
					else
					{
						dialog.getContentPane().removeAll();
						dialog.getContentPane().add(selectGui());
	   					dialog.validate();
	   				}
				}
				catch (InputException wpe)
	   			{
	   				comment.setText(wpe.getFehlerMeldung());
	   			}
	   			catch (IOException ioe)
	   			{
	   				JOptionPane.showMessageDialog(dialog,"Fehler beim Schreiben der Datei users.conf!!!",
		  							      		"Fehler",
                   	            				JOptionPane.ERROR_MESSAGE);	
            	}	
			}
		};
		schlie�en.addActionListener(al_schlie�en);
	//Layout Buttonleiste
		JPanel ButtonContainer = new JPanel();
		if (BenutzerContainer.isStart()) ButtonContainer.setLayout(new GridLayout(1,2));
		else ButtonContainer.setLayout(new GridLayout(1,3));
		ButtonContainer.add(anlegenContainer);
		if (!BenutzerContainer.isStart()) ButtonContainer.add(schlie�enContainer);
		ButtonContainer.add(abbrechenContainer);
	//Layout
		JPanel centerContainer = new JPanel(new GridLayout(4,2));
		centerContainer.add(nameLabel);
		centerContainer.add(nameContainer);
		centerContainer.add(passwordLabel);
		centerContainer.add(passwordContainer);
		centerContainer.add(passwordLabel1);
		centerContainer.add(passwordContainer1);
		centerContainer.add(pathLabel);
		centerContainer.add(pathContainer);
		centerContainer.setPreferredSize(new Dimension(320,120));
		JPanel center1Container = new JPanel(new FlowLayout());
		center1Container.add(centerContainer);
		JPanel content = new JPanel(new BorderLayout());
		content.setBorder(BorderFactory.createEmptyBorder (10,10,10,10));
		content.add("North",head);
		content.add("Center",center1Container);
		content.add("South",ButtonContainer);
		content.repaint();
		return content;
	}
	
	public static JPanel changeGui()
	{
	//title
		JLabel title = new JLabel((Icon) new ImageIcon(FUMP.class.getResource("bilder/Benutzeraendern.gif")));
	//comment
		comment.setText("");
		comment.setForeground(Color.red);
		comment.setHorizontalAlignment(JLabel.CENTER);
		JPanel commentContainer = new JPanel(new FlowLayout());
		commentContainer.setPreferredSize(new Dimension(320,25));
		commentContainer.add(comment);
	//title & comment Layout
		JPanel head = new JPanel(new BorderLayout());
		head.add("Center",title);
		head.add("South",commentContainer);
	//Name
		JLabel nameLabel = new JLabel("Benutzername:");
		final JLabel name = new JLabel((String) allUsers.getSelectedItem());
	//Passwort
		JLabel passwordLabel = new JLabel("Password eingeben:");
		final JPasswordField password = new JPasswordField(BenutzerContainer.getPassword((String) allUsers.getSelectedItem())); 
		password.setPreferredSize(new Dimension(150,25));
		JPanel passwordContainer = new JPanel(new FlowLayout());
		passwordContainer.add(password);
	//Passwort wiederholen
		JLabel passwordLabel1 = new JLabel("Password wiederholen:");
		final JPasswordField password1 = new JPasswordField(BenutzerContainer.getPassword((String) allUsers.getSelectedItem())); 
		password1.setPreferredSize(new Dimension(150,25));
		JPanel passwordContainer1 = new JPanel(new FlowLayout());
		passwordContainer1.add(password1);
	//Speicherpfad
		JLabel pathLabel = new JLabel("Speicherpfad:");
		final JTextField path = new JTextField(BenutzerContainer.getPath((String) allUsers.getSelectedItem()));
		path.setPreferredSize(new Dimension(120,25));
	//Pfad w�hlen Button
		JButton pathSelect = new JButton((Icon) new ImageIcon(FUMP.class.getResource("bilder/Open.gif")));
		pathSelect.setPreferredSize(new Dimension(25,25));
		ActionListener al_pathSelect = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
		   		JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				if (chooser.showDialog(dialog,"Verzeichnis w�hlen")==chooser.APPROVE_OPTION)
				{
					path.setText(chooser.getSelectedFile().toString());
				}
			}
		};
		pathSelect.addActionListener(al_pathSelect);
	//Pfad Layout	
		JPanel pathContainer = new JPanel(new FlowLayout());
		pathContainer.add(path);
		pathContainer.add(pathSelect);
	//Buttonleiste
	//anlegen
		JButton ok = new JButton("OK");
		ok.setMnemonic('o');
		ok.setPreferredSize(new Dimension(180,30));
		JPanel okContainer = new JPanel(new FlowLayout());
		okContainer.add(ok);
		ActionListener al_ok = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
	   			try
	   			{
		   			BenutzerContainer.changeBenutzer(name.getText(),BenutzerContainer.ToString(password.getPassword()),BenutzerContainer.ToString(password1.getPassword()),path.getText());
					dialog.getContentPane().removeAll();
	   				dialog.getContentPane().add(selectGui());
	   				dialog.validate();
				}
				catch(InputException ie)
				{
					comment.setText(ie.getFehlerMeldung());
					password.setText((BenutzerContainer.getPassword((String) allUsers.getSelectedItem())));
					password1.setText((BenutzerContainer.getPassword((String) allUsers.getSelectedItem())));
					path.setText(BenutzerContainer.getPath((String) allUsers.getSelectedItem()));
				}
				catch (IOException ioe)
	   			{
	   				System.out.println(ioe);
	   				JOptionPane.showMessageDialog(dialog,"Fehler beim Schreiben der Datei users.conf!!!",
		  						      			"Fehler",
                   	            				JOptionPane.ERROR_MESSAGE);	
                   	comment.setText("Die �nderungen konnten nicht gespeichert werden!");
        		}	
			}
		};
		ok.addActionListener(al_ok);
	//Abbrechen
		JButton abbrechen = new JButton("Abbrechen");
		abbrechen.setMnemonic('c');
		abbrechen.setPreferredSize(new Dimension(180,30));
		JPanel abbrechenContainer = new JPanel(new FlowLayout());
		abbrechenContainer.add(abbrechen);
		ActionListener al_abbrechen = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				dialog.getContentPane().removeAll();
	   			dialog.getContentPane().add(selectGui());
	   			dialog.validate();
			}
		};
		abbrechen.addActionListener(al_abbrechen);
	//Layout Buttonleiste
		JPanel ButtonContainer = new JPanel(new GridLayout(1,2));
		ButtonContainer.add(okContainer);
		ButtonContainer.add(abbrechenContainer);
	//Layout
		JPanel centerContainer = new JPanel(new GridLayout(4,2));
		centerContainer.add(nameLabel);
		centerContainer.add(name);
		centerContainer.add(passwordLabel);
		centerContainer.add(passwordContainer);
		centerContainer.add(passwordLabel1);
		centerContainer.add(passwordContainer1);
		centerContainer.add(pathLabel);
		centerContainer.add(pathContainer);
		centerContainer.setPreferredSize(new Dimension(320,120));
		JPanel center1Container = new JPanel(new FlowLayout());
		center1Container.add(centerContainer);
		JPanel content = new JPanel(new BorderLayout());
		content.setBorder(BorderFactory.createEmptyBorder (10,10,10,10));
		content.add("North",head);
		content.add("Center",center1Container);
		content.add("South",ButtonContainer);
		return content;
	}
}	
