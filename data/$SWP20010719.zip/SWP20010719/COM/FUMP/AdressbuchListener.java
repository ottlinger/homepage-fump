package com.fump;

import java.util.*;
import com.fump.*;

/**
*@version $Id: AdressbuchListener.java,v 1.1 2001/07/18 16:59:54 tbecker Exp $
*/


public interface AdressbuchListener extends EventListener
{
	public void adresseAbholen(AdressbuchEvent e);
}
