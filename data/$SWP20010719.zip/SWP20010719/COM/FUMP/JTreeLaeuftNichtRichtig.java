package com.fump;
/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: JTreeLaeuftNichtRichtig.java,v 1.1 2001/06/20 15:25:41 ottlinge Exp $
 */

    /** JTreeLaeuftNichtRichtig-Exception
    *  wenn ein Doedel versucht auf der Oberflaeche 
    *  zu arbeiten, obwohl diese noch nicht da ist
	* WIRD DIESE	 Exception geworfen
    */
public class JTreeLaeuftNichtRichtig extends Exception { }
