package com.fump;
/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: KeineUnterordnerDa.java,v 1.1 2001/06/20 15:25:42 ottlinge Exp $
 */

    /** KeineUnterordnerDa-Exception
    */
public class KeineUnterordnerDa extends Exception { }
