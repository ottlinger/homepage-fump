package com.fump;

import javax.mail.internet.*;
import javax.mail.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.net.*;
import java.util.*;
import com.fump.*;
import com.fump.hilfe.*;
import com.fump.bearbeiten.*;
import com.fump.filter.*;
import com.fump.pkonto.*;


public class FUMP extends JFrame implements ActionListener
{
	public static Image icon;

	static Dimension size;
	
	
	
	static Message dummy;
	
	
	
	//VorschauPanel vp;
	BenutzerContainer benutzercontainer;
	static Benutzer benutzer;
	
	JSplitPane mainSplit;
	static JSplitPane msgSplit;
	
	public static Hilfe hilfe;
	NeueMail neue_Mail;
        KontoContainer kontocontainer;
	
	Adressbuch adressbuch;

	Info info = new Info(this,true);

	JButton button_Hilfe = new JButton();
        JButton button_NeueMail = new JButton();
        JButton button_Mailholen = new JButton();
        JButton button_Weiter = new JButton();
        JButton button_Antwort = new JButton();
        JButton button_Loeschen = new JButton();
        JButton button_Adressbuch = new JButton();
        JButton button_Senden = new JButton();
	
	JScrollPane leftPane;
	static JPanel downPane;
	static VorschauPanel vorschau;
		
        JLabel benutzerName;
	FilterKontainer fk;
	
	public FUMP()
	{
		
		// Testmessage 1+2 erzeugen:
/********************************************************************************************************************/		

	try {
		Session session = Session.getInstance(new java.util.Properties());
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress("meine.from@email.de"));
		mimeMessage.setRecipient(Message.RecipientType.TO,new InternetAddress("meine.to@email.de"));
		mimeMessage.setRecipient(Message.RecipientType.CC,new InternetAddress("meine.cc@email.de"));
		mimeMessage.setRecipient(Message.RecipientType.BCC,new InternetAddress("meine.bcc@email.de"));
		mimeMessage.setSubject("Mal testen, ne?!");
		mimeMessage.setSentDate(new java.util.Date());

		//Content-Text erstellen
		String content = "Dies ist mein Content!!\n nix f�r dich!!!!";
		//ab in die Message
		mimeMessage.setContent(content, "text/plain");
		mimeMessage.saveChanges();
		System.out.println(mimeMessage.getContentType());
		dummy = (Message) mimeMessage;
	} catch (Exception e) {}
		
/*********************************************************************************************************************/



		setSize((int)(size.width*0.95),(int)(size.height*0.85));
		hilfe = new Hilfe(this);

		
		hilfe.setLocation((int)(size.width*0.29),(int)(size.height*0.1));

		icon = Toolkit.getDefaultToolkit().createImage(FUMP.class.getResource("bilder/e-logo_21x21.GIF"));
				 
		//enu
		JMenuBar menuBar = new JMenuBar();
		
		JMenu file = new JMenu("Datei");
		file.setFont(new Font("SansSerif",Font.PLAIN,14));
		JMenu edit = new JMenu("Bearbeiten");
		edit.setFont(new Font("SansSerif",Font.PLAIN,14));
		JMenu config = new JMenu("Einstellungen");
		config.setFont(new Font("SansSerif",Font.PLAIN,14));
		JMenu help = new JMenu("Hilfe");
		help.setFont(new Font("SansSerif",Font.PLAIN,14));
		
		//file menu's items	
		JMenuItem newMail = new JMenuItem("Neue Nachricht");
                newMail.setFont(new Font("SansSerif",Font.PLAIN,14));
		setCtrlAccelerator(newMail, 'N');
		newMail.addActionListener(this);
		JMenuItem newFolder = new JMenuItem("Neuer Ordner");
		newFolder.setFont(new Font("SansSerif",Font.PLAIN,14));
		setCtrlAccelerator(newFolder, 'O');
		newFolder.addActionListener(this);
		JMenuItem sendMsg = new JMenuItem("Nachricht(en) senden");
		sendMsg.setFont(new Font("SansSerif",Font.PLAIN,14));		
		setCtrlAccelerator(sendMsg, 'S');
		sendMsg.addActionListener(this);
		JMenuItem getMsg = new JMenuItem("Nachrichten holen");
		getMsg.setFont(new Font("SansSerif",Font.PLAIN,14));
		getMsg.addActionListener(this);
		JMenuItem exit = new JMenuItem("Beenden");
		exit.setFont(new Font("SansSerif",Font.PLAIN,14));
		exit.addActionListener(this);
		
		//edit menu's items
		JMenuItem cut = new JMenuItem("Ausschneiden");
		cut.setFont(new Font("SansSerif",Font.PLAIN,14));
		cut.addActionListener(this);
		JMenuItem copy = new JMenuItem("Kopieren");
		copy.setFont(new Font("SansSerif",Font.PLAIN,14));
		copy.addActionListener(this);
		JMenuItem delete = new JMenuItem("L�schen");
		delete.setFont(new Font("SansSerif",Font.PLAIN,14));
		delete.addActionListener(this);
		JMenuItem search = new JMenuItem("Suchen");
		search.setFont(new Font("SansSerif",Font.PLAIN,14));
		search.addActionListener(this);
			
		//config's items
		JMenuItem accounts = new JMenuItem("Kontos");
		accounts.setFont(new Font("SansSerif",Font.PLAIN,14));
		setCtrlAccelerator(accounts, 'K');
                accounts.addActionListener(this);
		JMenuItem filters = new JMenuItem("Filter");
		filters.setFont(new Font("SansSerif",Font.PLAIN,14));
		setCtrlAccelerator(filters, 'F');
  		filters.addActionListener(this);
		JMenuItem adress = new JMenuItem("Adressbuch");
		adress.setFont(new Font("SansSerif",Font.PLAIN,14));
		setCtrlAccelerator(adress, 'A');
  		adress.addActionListener(this);
		JMenuItem users = new JMenuItem("Benutzerverwaltung");
		users.setFont(new Font("SansSerif",Font.PLAIN,14));
		users.addActionListener(this);
		
		//help's items
		JMenuItem helpItem = new JMenuItem("Hilfe");
		helpItem.setFont(new Font("SansSerif",Font.PLAIN,14));
		setCtrlAccelerator(helpItem, 'H');
		helpItem.addActionListener(this);
		JMenuItem about = new JMenuItem("Info");
		about.setFont(new Font("SansSerif",Font.PLAIN,14));
		about.addActionListener(this);
		
		
		
		//making file menu
		file.add(newMail);
		file.add(newFolder);
		file.addSeparator();
		file.add(sendMsg);
		file.add(getMsg);
		file.addSeparator();
		file.add(exit); 
		
		//making edit menu
		edit.add(cut);
		edit.add(copy);
		edit.add(delete);
		edit.add(search);
		
		//making config menu
		config.add(accounts);
		config.add(filters);
		config.add(adress);
		config.add(users);

		//making help menu
		help.add(helpItem);
		help.add(about);

		//making menubar
		menuBar.add(file);
		menuBar.add(edit);
		menuBar.add(config);
		menuBar.add(help);

		//ToolBar
		JToolBar toolBar = new JToolBar();
		toolBar.setLayout(new GridLayout(1,1));

		    		
          	ImageIcon image_Hilfe = new ImageIcon(FUMP.class.getResource("bilder/e-help_50x30.GIF"));
    		ImageIcon image_NeueMail = new ImageIcon(FUMP.class.getResource("bilder/e-write_eMail_50x30.GIF"));
    		ImageIcon image_Mailholen = new ImageIcon(FUMP.class.getResource("bilder/e-get_new_eMail_50x30.GIF"));
    		ImageIcon image_Weiter = new ImageIcon(FUMP.class.getResource("bilder/e-forward_eMail_50x30.GIF"));
    		ImageIcon image_Antwort = new ImageIcon(FUMP.class.getResource("bilder/e-reply_to_50x30.GIF"));
    		ImageIcon image_Loeschen = new ImageIcon(FUMP.class.getResource("bilder/e-delete_eMail_50x30.GIF"));
		ImageIcon image_Adressen = new ImageIcon(FUMP.class.getResource("bilder/e-adrbook_50x30.GIF"));
		ImageIcon image_Senden = new   ImageIcon(FUMP.class.getResource("bilder/e-send_eMail_50x30.GIF"));
		
		button_Hilfe.setIcon(image_Hilfe);
		button_Hilfe.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
                button_Hilfe.addMouseListener(new MyMouseListener());
		button_Hilfe.addActionListener(this);
		button_Hilfe.setToolTipText("Hilfe");
        	button_NeueMail.setIcon(image_NeueMail);
 		button_NeueMail.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
		button_NeueMail.addActionListener(this);
                            button_NeueMail.addMouseListener(new  MyMouseListener());
		button_NeueMail.setToolTipText("Neue Nachricht schreiben");
        	button_Mailholen.setIcon(image_Mailholen);
		button_Mailholen.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
		button_Mailholen.addActionListener(this);
                            button_Mailholen.addMouseListener(new MyMouseListener());
		button_Mailholen.setToolTipText("Nachrichten holen");
        	button_Weiter.setIcon(image_Weiter);
                           button_Weiter.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
		button_Weiter.addActionListener(this);
                            button_Weiter.addMouseListener(new MyMouseListener());
		button_Weiter.setToolTipText("Weiterleiten");
        	button_Antwort.setIcon(image_Antwort);
                            button_Antwort.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
		button_Antwort.addActionListener(this);
                            button_Antwort.addMouseListener(new MyMouseListener());
		button_Antwort.setToolTipText("Antworten");
        	button_Loeschen.setIcon(image_Loeschen);
             		button_Loeschen.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
		button_Loeschen.addActionListener(this);	
                            button_Loeschen.addMouseListener(new MyMouseListener());
		button_Loeschen.setToolTipText("Mail l�schen");
               button_Adressbuch.setIcon(image_Adressen);
             		button_Adressbuch.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
		button_Adressbuch.addActionListener(this);	
                            button_Adressbuch.addMouseListener(new MyMouseListener());
		button_Adressbuch.setToolTipText("Adressbuch");
	 button_Senden.setIcon(image_Senden);
             		button_Senden.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
		button_Senden.addActionListener(this);	
                            button_Senden.addMouseListener(new MyMouseListener());
		button_Senden.setToolTipText("Nachrichten senden");

		JPanel links = new JPanel(new GridLayout(1,7));
		JPanel rechts = new JPanel(new GridLayout(1,5));
		JPanel container = new JPanel(new GridLayout(1,2));

              	 rechts.add(new Label());
                	rechts.add(new Label());
               	rechts.add(new Label());
                	rechts.add(new Label());
                	rechts.add(button_Hilfe);
		container.add(links);
		container.add(rechts);	

		toolBar.setLayout(new GridLayout(1,2));
		toolBar.setBorder(BorderFactory.createEtchedBorder());
                links.add(button_NeueMail);
		links.add(button_Mailholen);
		links.add(button_Senden);
		links.add(button_Antwort);
		links.add(button_Weiter);
		links.add(button_Loeschen);
		links.add(button_Adressbuch);
		
		rechts.add( button_Hilfe);

		toolBar.add(container);
		
		toolBar.setFloatable(false);
		
		//Assembling menu and toolbar in a JPanel
		JPanel menu_tools = new JPanel(new BorderLayout());
		menu_tools.add(BorderLayout.NORTH, menuBar);
		menu_tools.add(BorderLayout.SOUTH, toolBar);
		
		
		getContentPane().add(BorderLayout.NORTH, menu_tools);
		
		JScrollPane upPane = (JScrollPane)MailOberflaeche.zeigeMails();
		vorschau = new VorschauPanel();
		
		downPane = vorschau;
		
		
		//the 2 main split's creation + configuration 
		msgSplit = new JSplitPane();
		msgSplit.setOrientation(JSplitPane.VERTICAL_SPLIT);
		msgSplit.setDividerLocation(250);
		msgSplit.setLeftComponent(upPane);
		msgSplit.setRightComponent(downPane);
		msgSplit.setOneTouchExpandable(true);

		mainSplit = new JSplitPane();
		mainSplit.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
		mainSplit.setDividerLocation(200);
		
		mainSplit.setRightComponent(msgSplit);
		mainSplit.setOneTouchExpandable(true);

		
		//showing status
		
	      //	Font f = new Font("Status", Font.BOLD, 2);
		
		JPanel status = new JPanel(new BorderLayout()) ;
		benutzerName= new JLabel("  Benutzer Name  ");
                benutzerName.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
                status.add(BorderLayout.WEST,benutzerName);
		
		getContentPane().add(BorderLayout.CENTER, mainSplit);
		getContentPane().add(BorderLayout.SOUTH, status);

		
		

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
			// hier werden jetzt die Ordner und Mails gespeichert
			try { OrdnerOberflaeche.speichernBeimBeenden(); }
			catch(Exception speichernEcx) {};

				dispose();
				System.exit(0);
			}
		});

	}
	
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
                if(command.equals("Hilfe")) {
			hilfe.kontext_hilfe("Main");
			hilfe.setVisible(true);
			return;
		}

		if(command.equals("Neuer Ordner") ){
			return;
		}
		
		if(command.equals("Nachricht(en) senden")) {
			return;
		}
		
		if(command.equals("Nachrichten holen")) {
			kontocontainer.mailsAbrufen();
			return;
		}
		
		if(command.equals("Neue Nachricht")) {
			benutzer.neueMail();
			// aufruf �ber den benutzer -- janne
			//neue_Mail = new NeueMail(benutzer);
//			neue_Mail.setLocation((int)(size.width*0.25),(int)(size.height*0.1));
			return;
		}
	
		if(command.equals("Beenden")) {
			// hier werden jetzt die Ordner und Mails gespeichert
			try { OrdnerOberflaeche.speichernBeimBeenden(); }
			catch(Exception speichernEcx) {};
		
			System.exit(0);
		}

		if(command.equals("Filter")) {
			FilterKontainerView filter = new FilterKontainerView(fk);
			filter.setLocation((int)(size.width*0.25),(int)(size.height*0.3));
			filter.setVisible(true);
			return;
		}

	             if(command.equals("Kontos")){
		     			kontocontainer = benutzer.gibKontoKontainer();
                        		if(kontocontainer==null) {kontocontainer=new
					KontoContainer(benutzer.getName(),benutzer.getPath(),true);         
                                           			       kontocontainer.kontoGBS();
                                                 			}
                        		else                     	kontocontainer.kontoGBS();
                        	return;
                	}

 		if(command.equals("Info")) {
			Info.flag=true;
			info.setVisible(true);
			info.repaint();
			return;
		}
	
		if(command.equals("Adressbuch")) {
			
			
			try {
			
			adressbuch = benutzer.gibAdressbuch();

			adressbuch.pack();
			adressbuch.setLocation((int)(size.width*0.25),(int)(size.height*0.1));
			adressbuch.show();
			
			}   catch(Exception ex) { System.out.println("IO-Fehler beim Anlegen des Adressbuches"); }
		}
		if(command.equals("Benutzerverwaltung")) {
			System.out.println(command);
			benutzercontainer.benutzerVerwaltung(this);
			setBenutzerText();
			return;
		}

		
		if(command.equals("Suchen")) {
			SucheView sw = new SucheView();
		}
		

		if(e.getSource().equals(button_Hilfe)) {
                           		hilfe.kontext_hilfe("Main");
			//hilfe.setVisible(true);		
                  		return;
                	}

		if(e.getSource().equals(button_NeueMail)) {
			
			benutzer.neueMail();
// aufruf �ber den benutzer -- janne
//			neue_Mail = new NeueMail(benutzer);
//			neue_Mail.setLocation((int)(size.width*0.25),(int)(size.height*0.1));
			return;
	  	}

		
		if(e.getSource().equals(button_Mailholen)) {
			kontocontainer.mailsAbrufen();
			
			
			return;
	  	}

		if(e.getSource().equals(button_Adressbuch)) {

			
			//nur zum Test der KontextHilfe:
			//hilfe.kontext_hilfe("Adressbuch"); return;

			try {
			adressbuch = benutzer.gibAdressbuch();
			//if(adressbuch==null) adressbuch.setzeAdressbuch(new Adressbuch(benutzer.getName(),benutzer.getPath(),true));
			adressbuch.pack();
			adressbuch.setLocation((int)(size.width*0.25),(int)(size.height*0.1));
			adressbuch.show();
			
			}catch (Exception ex) { System.out.println("IO-Fehler beim Anlegen des Adressbuches");}
		}
		
		if(e.getSource().equals(button_Loeschen)) {

			MailOberflaeche.tabelle.addNotify();
			int result=JOptionPane.showConfirmDialog(null, "Soll die Mail \ngeloescht werden ?","Loeschbestaetigung", JOptionPane.YES_NO_OPTION);
			// Nur wenn JA geklickt wurde loeschen
			if(result==JOptionPane.YES_OPTION) {
				try  {

					Mail m=((TabellenModell).aktuelleMail(MailOberflaeche.tabelle.getSelectedRow()));
					m.loeschen();
					 // JTable erzeugen mit entsprechendem Modell
					MailOberflaeche.tabelle.addNotify();
      	    } // end of try

	         catch(ObjektIstGeschuetzt ue) {
		          JOptionPane.showMessageDialog(null, "Kann nicht geloescht werden.", "Geschuetztes Element", JOptionPane.INFORMATION_MESSAGE);
				} // end of catch
				catch(ArrayIndexOutOfBoundsException x) {
					JOptionPane.showMessageDialog(null, "Bitte im Ordnerfenster einen Ordner markieren", "Keine Markierung", JOptionPane.ERROR_MESSAGE);
				} // end of catch
				catch(Exception x){
					System.out.println(x.toString());
				}
			} // resultif

			//markierte Mails L�schen
			return;
		}
		if(e.getSource().equals(button_Antwort)) {
			MailOberflaeche.tabelle.addNotify();
			try {
				Mail m = (TabellenModell.aktuelleMail(MailOberflaeche.tabelle.getSelectedRow()));
			 	NeueMail n = new NeueMail(BenutzerContainer.getBenutzer(),m/*.macheMessageDraus()*/,true);
				n.addNeueMailGeschriebenListener(BenutzerContainer.getBenutzer());
			} // end of try
		  catch(ArrayIndexOutOfBoundsException x) {
	        JOptionPane.showMessageDialog(null, "Bitte im Ordnerfenster einen Ordner markieren", "Keine Markierung", JOptionPane.ERROR_MESSAGE);
	     } // end of catch
 			
			catch(Exception x) {;
			} // end of catch
      
			//Auf markierte Mails antworten
			return;
		}
		if(e.getSource().equals(button_Senden)) {

			//Mails senden
			return;
		}
		if(e.getSource().equals(button_Weiter)) {

			//Mails weiterleiten
			return;
		}
		
	}
	
	//Methode zu reinitialisieren der Gui, wenn der Benutzer ge�ndert wurde
	//author Janne (Benutzer)
	//w�re m�glich, diese  Methode auch aus createBenutzer aufzurufen
	public void setBenutzer(Benutzer benutzer)
	{
			// hier werden jetzt die Ordner und Mails gespeichert
			try { OrdnerOberflaeche.speichernBeimBeenden(); }
			catch(Exception speichernEcx) {};
		
		System.out.println("Fump: setBenutzer aufgerufen f�r: "+benutzer.getName()); 
		this.benutzer = benutzer;
		
		leftPane.removeAll();
		leftPane = (JScrollPane) OrdnerOberflaeche.zeigeOrdner(benutzer.getName());
		leftPane.validate();

		kontocontainer = benutzer.gibKontoKontainer();
		fk = benutzer.gibFilterKontainer();
		setBenutzerText();
		setLeftComponent();
		//setVisible(true);
		//validate();
	}
	
	//Benutzer-anmeldung
	
	public boolean createBenutzer() {

			benutzercontainer = new BenutzerContainer((JFrame)this);
			while(benutzer==null) { try { Thread.sleep(100); }
						catch (Exception e) {}  }
			leftPane = (JScrollPane) OrdnerOberflaeche.zeigeOrdner(benutzer.getName());
			
			kontocontainer = benutzer.gibKontoKontainer();
			fk = benutzer.gibFilterKontainer();
			benutzerName.setText("    Aktueller Benutzer ist : "+benutzer.getName()+"    ");
			return true;
			
	}
	
	public boolean setBenutzerText() {
			benutzerName.setText("    Aktueller Benutzer ist : "+benutzer.getName()+"    ");
			return true;
	}


	public void setLeftComponent() {
			if(leftPane!=null) mainSplit.setLeftComponent(leftPane);
			else System.out.println("leftpane=null");
	}
	
	public static void zeigeAn(Message m) {
		
			
			msgSplit.remove(downPane);
			
			downPane= new VorschauPanel(m) ;
			msgSplit.setRightComponent(downPane);
			downPane.setVisible(true);
			downPane.validate();
	}
	
	public static void main(String args[])
	{

		size=Toolkit.getDefaultToolkit().getScreenSize();

		Logo logo = new Logo();
		logo.window.setLocation((int)(size.width*0.35),(int)(size.height*0.35));
		logo.setVisible();
	
		System.out.println("Starting Main...");
		FUMP mainFrame = new FUMP();

	
		mainFrame.setLocation((int)(size.width*0.025), (int)(size.height*0.05));
		mainFrame.setTitle("FUMP");
		mainFrame.setIconImage(icon);
		logo.destroyLogo();
		mainFrame.createBenutzer();
		mainFrame.setLeftComponent();
		mainFrame.setVisible(true);
		
		
	}
	private void setCtrlAccelerator(JMenuItem mi, char acc) {
		KeyStroke ks = KeyStroke.getKeyStroke(acc,Event.SHIFT_MASK);
		mi.setAccelerator(ks);
	}
}
