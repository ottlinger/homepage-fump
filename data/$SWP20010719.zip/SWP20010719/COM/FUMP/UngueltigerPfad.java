package com.fump;

/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: UngueltigerPfad.java,v 1.1 2001/06/20 15:25:44 ottlinge Exp $
 */

    /** UngueltigerPfad-Exception
    */
public class UngueltigerPfad extends Exception {}