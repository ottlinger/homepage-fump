package com.fump;

import javax.mail.*;
import javax.mail.Flags;
import javax.mail.search.*;
import javax.mail.internet.InternetAddress;
import java.util.*;
import java.io.*;
import java.util.Date;
import javax.activation.*;
import javax.swing.tree.*;
import javax.swing.*;
/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: DummyMail.java,v 1.1 2001/07/14 21:27:24 ottlinge Exp $
 */
public class DummyMail extends Message {
// Interface - einfach so reingemacht
// Funktionen, die schon sauber implementiert sind,
// finden sich weiter hinten im Code ;-) PO 20010617


  public Enumeration getNonMatchingHeaders(String[] p0) throws MessagingException {return null; }
  public void setFrom() throws MessagingException {}
  public void setFrom(Address p0) throws MessagingException {}
  public void addFrom(Address[] p0) throws MessagingException {}
  public Address[] getRecipients(RecipientType p0) throws MessagingException { return null;}
  public Address[] getAllRecipients() throws MessagingException { return null; }
  public void setRecipients(RecipientType p0, Address[] p1) throws MessagingException { }
  public void setRecipient(RecipientType p0, Address p1) throws MessagingException { }
  public void addRecipients(RecipientType p0, Address[] p1) throws MessagingException {}
  public void addRecipient(RecipientType p0, Address p1) throws MessagingException { }
  public Address[] getReplyTo() throws MessagingException { return null; }
  public void setReplyTo(Address[] p0) throws MessagingException { }
  public void setSubject(String p0) throws MessagingException {}
  public Date getSentDate() throws MessagingException { return null; }
  public void setSentDate(Date p0) throws MessagingException { }
  public Date getReceivedDate() throws MessagingException { return null; }
  public Flags getFlags() throws MessagingException { return null; }
  public boolean isSet(Flags p0) throws MessagingException { return true; }
  public void setFlags(Flags p0, boolean p1) throws MessagingException {}
  public void setFlag(Flags p0, boolean p1) throws MessagingException { }
  public int getMessageNumber() { return -1; }
  protected void setMessageNumber(int p0) { }
  public Folder getFolder() { return null;  }
  public boolean isExpunged() { return false;  }
  protected void setExpunged(Boolean p0) { }
  public Message reply(boolean p0) throws MessagingException { return null; }
  public void saveChanges() throws MessagingException { }
  public boolean match(SearchTerm p0) throws MessagingException {return false;  }
// elemente.capacity(); ?
  public int getSize() throws MessagingException { return -1;  }
// ??
  public int getLineCount() throws MessagingException { return -1;  }
  public String getContentType() throws MessagingException { return null;  }
// isinstanceof MIME ??
  public boolean isMimeType(String p0) throws MessagingException {return false;  }
  public String getDisposition() throws MessagingException { return null;  }
  public void setDisposition(String p0) throws MessagingException { }
  public String getDescription() throws MessagingException { return null;  }
  public void setDescription(String p0) throws MessagingException { }
  public String getFileName() throws MessagingException { return null;  }
  public void setFileName(String p0) throws MessagingException { }
  public InputStream getInputStream() throws IOException, MessagingException { return null;  }
  public DataHandler getDataHandler() throws MessagingException { return null;  }
  public Object getContent() throws IOException, MessagingException { return null; }
  public void setDataHandler(DataHandler p0) throws MessagingException { }
  public void setContent(Object p0, String p1) throws MessagingException { }
  public void setText(String p0) throws MessagingException { }
  public void setContent(Multipart p0) throws MessagingException { }
  public void writeTo(OutputStream p0) throws IOException, MessagingException { }
  public String[] getHeader(String p0) throws MessagingException { return null; }
  public void setHeader(String p0, String p1) throws MessagingException { }
  public void addHeader(String p0, String p1) throws MessagingException { }
  public void removeHeader(String p0) throws MessagingException { }
  public Enumeration getAllHeaders() throws MessagingException {return null; }
  public Enumeration getMatchingHeaders(String[] p0) throws MessagingException {return null; }
  public String getSubject() { return null;}
  public Address[] getFrom() throws MessagingException { return null; }


public DummyMail() {
super();
} // end of Konstruktor
} // end of class

