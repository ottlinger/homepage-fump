package com.fump;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.io.File;
import com.fump.bearbeiten.*;
import com.fump.pkonto.*;
import com.fump.hilfe.*;
import com.fump.filter.*;

/**
 * @author B. Hentrich, J. K. Olesen
 * @version $Id: Benutzer.java,v 1.22 2001/07/18 17:01:51 tbecker Exp $
 */
/**
*Stellt Funktionen zur Kommunikation zwischen den einzelnen Komponenten von FUMP her.
*/
public class Benutzer implements NeueMailGeschriebenListener,WillAntwortMailSchreibenListener
{
	private String name;
 	private String path;
	private Adressbuch theAdressbuch;
//	private OrdnerOberflaeche rootOrdner;
	private FilterKontainer theFilterContainer;
	private KontoContainer theKontoContainer;
   
/**
*Constructor
*ruft Constructoren von Adressbuch, KontoContainer, FilterContainer, Ordneroberflaeche auf.
*@param name der Benutzername.
*@param path Speicherpfad f�r Benutzerdateien.
*@param existiert true=Benutzer hat bereits Benutzerdateien, false sonst.
*/
	public Benutzer(String name, String path, boolean existiert)
 	{
		this.name = name;
		this.path = path;
//		rootOrdner = new OrdnerOberflaeche(name, path, existiert);
		theKontoContainer = new KontoContainer(name, path, existiert);
		theAdressbuch = new Adressbuch(name, path, !existiert);
		theFilterContainer = new FilterKontainer(name, path,existiert);
	}
/**
*Gibt den Benutzernamen zur�ck.
*@return String den Benutzernamen.
*/
   	public String getName()
   	{
   		return name;
   	}

/**
*Gibt den Speicherpfad des Benutzers zur�ck.
*@return String der Speicherpfad.
*/   	
   	public String getPath()
   	{
   		return path;
   	}

/**
*Gibt den KontoContainer des Benutzers zur�ck.
*@return KontoContainer der KontoContainer.
*/   	   	
   	public KontoContainer gibKontoKontainer()
   	{
		return theKontoContainer;
   	}

/**
*Gibt das Adressbuch des Benutzers zur�ck.
*@return Adressbuch das Adressbuch.
*/   	   	
   	public Adressbuch gibAdressbuch()
   	{
		return theAdressbuch;
   	}

	public void setzeAdressbuch(Adressbuch adr)
	{
		theAdressbuch = adr;
	}

/**
*Gibt den rootOrdner des Benutzers zur�ck.
*@return OrdnerOberflaeche der RootOrdner.
*/   	   	   	
//   	public OrdnerOberflaeche getRootOrdner()
//	{
//  		return rootOrdner;
//	}

/**
*Gibt den FilterKontainer des Benutzers zur�ck.
*@return FilterKontainer der FilterKontainer.
*/   	   	
	public FilterKontainer gibFilterKontainer()
  	{
    		return theFilterContainer;
   	}

//????	   
//  	private void �ndernDanke()
//   	{
//   	}

/**
*Senden aller geschriebenen Mails.
*/   	   	  
	public void alleKontenSenden()
   	{
   	}

/**
*Mails von allen Konten abrufen.
*/   	   	  
	public void alleKontenAbrufen()
   	{
   		theKontoContainer.mailsAbrufen();
	}
	
   

//Sachen der neueMail geschrieben Leute

  	public void neueMail()
  	{
		System.out.println("Benutzer: es soll ein mail geschrieben werden");
		NeueMail n = new NeueMail(this);
		n.addNeueMailGeschriebenListener(this);
   	}

   	public void geschriebeneMailAbholen(NeueMailGeschriebenEvent e)
  	{
		String from = e.getAbsender();
		String to= e.getEmpfaengerTo();
		String subject= e.getBetreff();
	 	String mailText= e.getMailText();
		File [] attachments = e.getAnhaengsel();
		String cc=e.getEmpfaengerCC();
		String bcc=e.getEmpfaengerBCC();
		try{
		System.out.println("Benutzer: Benutzer schickt mail an:" + to);
		theKontoContainer.gibKonto(from).mailSenden(to, cc, bcc,subject,mailText, attachments);
		}
		catch (KeinSolchesKontoFehler kskf)
		{
			System.out.println("Benutzer.java: Sollte mail senden �ber konto"+from+" Konto gibt es nicht!");
		}
//		((Konto)theKontoContainer.konten.elementAt(0)).mailSenden(to, cc, bcc,subject,mailText, attachments);

	}

	public void antwortMailSchreiben(WillAntwortMailSchreibenEvent e)
	{
		NeueMail n = new NeueMail(this,e);
		n.addNeueMailGeschriebenListener(this);
	}
} 
