package com.fump;

/**
*  @author Tobias Becker (tbecker), Joerg Dieckmann (dieck)
*  @version $Id: AdressbuchEvent.java,v 1.1 2001/07/18 17:00:18 tbecker Exp $
*/

import com.fump.*;
import javax.swing.event.*;
import java.util.*;
import java.io.*;

public class AdressbuchEvent extends EventObject
{
	private String adressen;
	private int adressenArt;
		
	public AdressbuchEvent(Object source, String adressen,int adrart)
	{
		super(source);
		this.adressen=adressen;
		adressenArt=adrart;
	}

	public String getAdressen()
	{
		return adressen;
	}
	
	public int getAdressenArt()
	{
		return adressenArt;
	}
}