package com.fump;

/**
*  @author Markus und Philipp
*  @version $Id: KopierenListener.java,v 1.1 2001/07/14 23:28:13 ottlinge Exp $ 
*/

import java.util.*;
import com.fump.*;

public interface KopierenListener extends EventListener {
	public void kopierenFertig(KopierenEvent e);
} // end of class
