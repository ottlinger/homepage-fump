package com.fump;

/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: DoppelterName.java,v 1.1 2001/06/20 15:25:40 ottlinge Exp $
 */

    /** DoppelterName-Exception
    */
public class DoppelterName extends Exception {}