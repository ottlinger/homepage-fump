package com.fump;
/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: UngueltigerName.java,v 1.1 2001/06/20 15:25:44 ottlinge Exp $
 */

    /** UngueltigerName-Exception
    */
public class UngueltigerName extends Exception { }
