package com.fump;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.awt.Point;
import java.io.*;
import javax.swing.event.*;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.JOptionPane;
import java.awt.Container;
import java.io.IOException;
import com.fump.hilfe.*;
import java.awt.Dimension;

/**
*@version $Id: Adressbuch.java,v 1.17 2001/07/18 16:59:13 tbecker Exp $
*/

public class Adressbuch extends JFrame implements ActionListener{
	public Vector eintraege;
	String pfad;
	String theBenutzer;
	JTable table;
	JScrollPane scrollPane;
	Eintrag neuerEintrag;	
	protected int row;
	JPanel panel, mpanel, unten;
	JButton eintrag_loeschen, person_neu, gruppe_neu, hilfe, ok, aendern, nur_perso, nur_grup, ende;
	int selRow=Integer.MIN_VALUE;
	String ausgewaehlteAdressen = "";
	int art=0;


	private EventListenerList listenerList = new EventListenerList();
	private AdressbuchEvent adressbuchEvent = null;

	public void addAdressbuchListener(AdressbuchListener l)
	{
		listenerList.add(AdressbuchListener.class,l);
	}
	
	public void removeAdressbuchListener(AdressbuchListener l)
	{
		listenerList.remove(AdressbuchListener.class,l);
	}
	
	protected void fireAdressbuchEvent(String adressen)
	{
		Object[] listeners = listenerList.getListenerList();
		for (int i = listeners.length-2;i>=0;i-=2)
		{
			if (listeners[i] == AdressbuchListener.class)
			{
				if (adressbuchEvent == null)
				{
					adressbuchEvent = new AdressbuchEvent(this,adressen,art);
				}
				((AdressbuchListener)listeners[i+1]).adresseAbholen(adressbuchEvent);
			}
		}
		ausgewaehlteAdressen="";
		adressbuchEvent=null;
	} 		

	public void setAdressenArt(int nummer)
	{
		this.art=nummer;
		ausgewaehlteAdressen="";
		adressbuchEvent=null;
	}


/**
	*@param Benutzer benutzer - die / der BenutzerIn, der  / dem das Adressbuch geh�rt
	*@param boolean neu - true, wenn Adressbuch das erste Mal angelegt wird
*/

	public Adressbuch(String benutzer, String path, boolean neu) {
		super("Adressbuch");
	// neu true: Adressbuch neu anlegen
			this.theBenutzer = benutzer;
			pfad = path+File.separator+theBenutzer+".adr";
			if(!neu){
				System.out.println("kein Neuer user");
				try{ 
					eintraege =DatenLeser.laden(pfad);
				}
				catch (IOException e){
//					JOptionPane.showMessageDialog(this,"Beim Lesen der Datei ist ein Fehler aufgetreten","Fehler",JOptionPane.ERROR_MESSAGE);
					System.out.println("Fehler beim Lesen der Adressbuchdatei");
					eintraege=new Vector();
					this.dispose();
				}
			}//if(!neu)		
			else {
				eintraege = new Vector();
				DatenLeser.speichern(eintraege,pfad);
				System.out.println("adr gesp");
			}
			init();
	}

	private void init(){
		AbuchTableModel mod = new AbuchTableModel(this);	
		table = new JTable(mod);
		mod.addTableModelListener(table);
		table.getTableHeader().addMouseListener(new java.awt.event.MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				header_clicked(e);
			}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListSelectionModel rows = table.getSelectionModel();
		rows.addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent e){
				if(e.getValueIsAdjusting())return;
				ListSelectionModel lsm = (ListSelectionModel)e.getSource();
				selRow = lsm.getMinSelectionIndex();
			}
		});
		
		this.getContentPane().setLayout(new BorderLayout());
		scrollPane = new JScrollPane(table);
		mpanel = new JPanel(new BorderLayout());		// mpanel zeigt JTable mit Eintr�gen an
		mpanel.add(scrollPane,BorderLayout.NORTH);
		this.getContentPane().add(mpanel, BorderLayout.CENTER);

		eintrag_loeschen = new JButton("<html><font size=-2>l&ouml;schen</font></html>");
		eintrag_loeschen.setToolTipText("den gew�hlten Eintrag l�schen");
		eintrag_loeschen.addActionListener(this);
		person_neu = new JButton("<html><font size=-2>neue Person</font></html>");
		person_neu.setToolTipText("einen neuen Personeneintrag anlegen");
		person_neu.addActionListener(this);
		gruppe_neu = new JButton("<html><font size=-2>neue Gruppe</font></html>");
		gruppe_neu.setToolTipText("Einen neuen Gruppeneintrag anlegen");
		gruppe_neu.addActionListener(this);
		hilfe = new JButton((Icon)new ImageIcon(FUMP.class.getResource("bilder/e-help_klein.gif")));
		hilfe.setToolTipText("hilfe");
		hilfe.addActionListener(this);
		ok = new JButton("<html><font size=-2>ok</font></html>");
		ok.setToolTipText("Adresse �bernehmen");
		ok.addActionListener(this);
		aendern = new JButton ("<html><font size=-2>&auml;ndern</font></html>");
		aendern.setToolTipText("den markierten Eintrag �ndern");
		aendern.addActionListener(this);
		ende = new JButton("<html><font size=-2>ende</font></html>");
		ende.setToolTipText("Adressbuch schliessen");
		ende.addActionListener(this);


		panel = new JPanel(new FlowLayout());		// panel: Buttonleiste
		panel.add(eintrag_loeschen);
		panel.add(person_neu);
		panel.add(gruppe_neu);
		panel.add(ok);
		panel.add(aendern);
		panel.add(ende);
		panel.add(hilfe);
		this.getContentPane().add(panel, BorderLayout.NORTH);
		
		unten = new JPanel();
		nur_perso = new JButton("<html><font size=-2>nur Personen<br>anzeigen</html>");
		nur_perso.setToolTipText("ein neues Fenster �ffnen, in dem nur die Personeneintr�ge angezeigt werden");
		nur_perso.addActionListener(this);
		nur_grup = new JButton("<html><font size=-2>nur Gruppen<br>anzeigen</html>");
		nur_grup.setToolTipText("ein neues Fenster �ffnen, in dem nur die Gruppeneintr�ge angezeigt werden");
		nur_grup.addActionListener(this);
		unten.add(nur_perso);
		unten.add(nur_grup);
		this.getContentPane().add(unten, BorderLayout.SOUTH);
		
	} //init()

	public void actionPerformed(ActionEvent e){

		if(e.getSource() instanceof JButton){
			if(e.getSource()==aendern){
				if(selRow==Integer.MIN_VALUE){
					JOptionPane.showMessageDialog(this, "Bitte waehlen Sie zuerst einen Eintag aus!","Nachricht",JOptionPane.INFORMATION_MESSAGE);
				}
				else{
					AdresseAendern m = new AdresseAendern(this, "", true, this,selRow);
				}
				DatenLeser.speichern(this.eintraege,this.pfad);

			}
				
			if(e.getSource()==hilfe){FUMP.hilfe.kontext_hilfe("Adressbuch");}
			if(e.getSource()==eintrag_loeschen){
				if(selRow==Integer.MIN_VALUE){
					JOptionPane.showMessageDialog(this,"Bitte w�hlen Sie zuerst einen Eintrag aus!","Nachricht",
					JOptionPane.INFORMATION_MESSAGE);
				}
				else{
					int y = JOptionPane.showConfirmDialog(this,"den gew�hlten Eintrag wirklich l�schen?","Warnung",JOptionPane.YES_NO_OPTION);
					// gew�hlten Eintrag l�schen:
					if(y==JOptionPane.YES_OPTION){
						this.eintraege.removeElementAt(selRow);
						table.repaint();
						table.addNotify();
					}
				}
				DatenLeser.speichern(this.eintraege,this.pfad);

			}
			if(e.getSource()==person_neu){
				NeuenEintragAnlegen neu = new NeuenEintragAnlegen(this, true, this, false,"Neue Person anlegen");
				DatenLeser.speichern(this.eintraege,this.pfad);
				table.addNotify();
			}
			if(e.getSource()==gruppe_neu){
				NeuenEintragAnlegen neu = new NeuenEintragAnlegen(this, true, this,true,"Neue Gruppe anlegen");
				DatenLeser.speichern(this.eintraege,this.pfad);
				table.addNotify();
			}
			if(e.getSource()==ok){
				if(selRow==Integer.MIN_VALUE){
					JOptionPane.showMessageDialog(this, "Bitte waehlen Sie zuerst einen Eintrag aus!", "Nachricht", JOptionPane.INFORMATION_MESSAGE);
				}
				else{
					getAusgewaehlteAdressen(selRow);
					DatenLeser.speichern(this.eintraege,this.pfad);
					fireAdressbuchEvent(ausgewaehlteAdressen);
					this.dispose();
				}
			}
			if(e.getSource()==ende){
				int x = JOptionPane.showConfirmDialog(this,"Adressbuch schliessen?","Warnung",JOptionPane.YES_NO_OPTION);
				if(x==JOptionPane.YES_OPTION){
					DatenLeser.speichern(this.eintraege, this.pfad);
					this.dispose();
				}
			}
			if(e.getSource()==nur_grup){NurGruppenOderPersonenAnzeigen gruppe = new NurGruppenOderPersonenAnzeigen(this,"Nur Gruppen anzeigen",true,true);}
			if(e.getSource()==nur_perso){NurGruppenOderPersonenAnzeigen person = new NurGruppenOderPersonenAnzeigen(this,"Nur Personen anzeigen",true,false);}

		}//if(e.getSource() instanceof JButton)
		
	}//actionPerformed
	
	/**
	*@param Eintrag e - der Eintrag, der eingef�gt werden soll
	*/

	public void addNeuenEintrag(Eintrag e){
		eintraege.add(e);
		DatenLeser.speichern(this.eintraege,this.pfad);
		table.addNotify();
	}
	
	/**
	*@param Eintrag e - Eintrag, der gel�scht werden soll
	*/

	private void loeschenEintrag(Eintrag e){
		eintraege.remove(e);
		DatenLeser.speichern(this.eintraege,this.pfad);
		table.addNotify();
	}

	/**
	*@param String name - Name des zu �ndernden Eintrags
	*@param Eintrag e - neuer Eintrag
	*/

	public void eintragAendern(String name, Eintrag e){
		for(int i = 0; i<eintraege.size(); i++){
			if(((Eintrag)eintraege.elementAt(i)).getName().equals(name)){
				eintraege.setElementAt(e,i);
				break;	// falls der Eintrag vorhanden ist: aendern, for-Schleife beenden
			} // ende if
		}	// ende for
		DatenLeser.speichern(this.eintraege,this.pfad);
		table.addNotify();
	}

	/**
		*@param int row - ausgew�hlter Eintrag
		*@return String ausgew�hlteAdressen 
	*/
	
	public String getAusgewaehlteAdressen(int x){
		Eintrag tmp = (Eintrag)eintraege.elementAt(x);
		ausgewaehlteAdressen="";
		for(int i = 0; i<tmp.adressen.size(); i++){
			ausgewaehlteAdressen += ((String)tmp.adressen.elementAt(i)+", ");
		}
		if(ausgewaehlteAdressen.endsWith(", "))ausgewaehlteAdressen = ausgewaehlteAdressen.substring(0,ausgewaehlteAdressen.length()-2);
		return ausgewaehlteAdressen;
	}
	
	public String getAusgewaehlteAdressen(){
		return ausgewaehlteAdressen;
	}

	public void eintragNeuSetzen(Eintrag e, int x){
		for(int i = 0; i<eintraege.size(); i++){
			Eintrag d = (Eintrag)eintraege.elementAt(i);
			//System.out.println(d.getName()+" "+d.getAlias()+" "+d.getAdressenString());
		}
		this.eintraege.setElementAt(e,x);
		for(int i = 0; i<eintraege.size(); i++){
			Eintrag d = (Eintrag)eintraege.elementAt(i);
			//System.out.println(d.getName()+" "+d.getAlias()+" "+d.getAdressenString());
		}
		DatenLeser.speichern(this.eintraege,this.pfad);
	}

	public void header_clicked(MouseEvent e){
		int column = table.columnAtPoint(new Point(e.getX(), e.getY()));
		int indexDaten = table.convertColumnIndexToModel (column);
		sortiere(indexDaten);
		table.addNotify();
	}

	public void sortiere(int indexDaten){
		switch (indexDaten){
			case 0: Collections.sort(eintraege, new NameComp()); break;
			case 1: Collections.sort(eintraege, new AliasComp()); break;
			case 2: Collections.sort(eintraege, new AdressComp()); break;
		}
	}
	
	/**
	*@return dieses Adressbuch
	*/
	
	public Adressbuch getAdressbuch(){
		return this;
	}

/*	public static void main(String[] args) {
		Adressbuch test = new Adressbuch("NeuTest","/home/elfe/eschner", false);
		test.pack();
		test.setVisible(true);
		test.setSize(test.getPreferredSize());
	}*/
}

class NameComp implements Comparator{
	public NameComp(){}
	public int compare(Object o1, Object o2){
		Eintrag e1 = (Eintrag) o1;
		Eintrag e2 = (Eintrag) o2;
		return e1.getName().compareTo(e2.getName());
	}
}

class AliasComp implements Comparator{
	public AliasComp(){}
	public int compare(Object o1, Object o2){
		Eintrag e1 = (Eintrag) o1;
		Eintrag e2 = (Eintrag) o2;
		return e1.getAlias().compareTo(e2.getAlias());
	}
}

class AdressComp implements Comparator{
	public AdressComp(){}
	public int compare(Object o1, Object o2){
		Eintrag e1 = (Eintrag) o1;
		Eintrag e2 = (Eintrag) o2;
		return e1.getAdressenString().compareTo(e2.getAdressenString());
	}
}
