package com.fump.pkonto;


class SpeichernFehler extends Exception{}
