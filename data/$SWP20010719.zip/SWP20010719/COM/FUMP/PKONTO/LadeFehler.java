package com.fump.pkonto;

class LadeFehler extends Exception{}
