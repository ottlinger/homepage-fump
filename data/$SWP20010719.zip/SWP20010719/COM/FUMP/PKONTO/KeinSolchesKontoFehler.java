package com.fump.pkonto;


public class KeinSolchesKontoFehler extends Exception{}
