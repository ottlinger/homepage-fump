package com.fump.pkonto;

class KontoExistiertSchonFehler extends Exception{} 

