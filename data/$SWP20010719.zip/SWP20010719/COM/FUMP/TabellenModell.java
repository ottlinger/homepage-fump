package com.fump;

import javax.swing.table.AbstractTableModel;
import javax.swing.tree.*;
import javax.swing.*;
import javax.mail.*;
import java.util.*;

/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: TabellenModell.java,v 1.12 2001/07/14 18:57:35 ottlinge Exp $
 */
class TabellenModell extends AbstractTableModel {

// tabellenzeilen
public String[] columnNames=
    {"Betreff","Absender","Datum","Gelesen"};
//public Object[][] data;


      /** Hilfsfunktion: gibt Anzahl der Spalten zur�ck
         *  @param
         *  @return int
         *  @exception
         */
        public int getColumnCount() { return columnNames.length; }

      /** Hilfsfunktion: gibt Anzahl der Reihen zur�ck
         *  @param
         *  @return int
         *  @exception
         */
        public int getRowCount() {
			try {
	        // aktuellen Pfad rausfinden
	        TreePath pfad=OrdnerOberflaeche.gibAktPfad();
//System.out.println("Pfad "+pfad);
	        // Vector auf Mailobjekte gewinnen
	        Vector mailVec;
	        Object temp=OrdnerOberflaeche.gibAktuelleWurzelAlsObjekt().getPfadAlsVector(pfad).lastElement();
//System.out.println("tempOrdner= "+temp);
	        if(temp instanceof Ordner){
    	       mailVec= ((Ordner)temp).gibAlleMails();
//System.out.println("mailvec = "+mailVec);
	        int anzahl=mailVec.size();
//System.out.println("tabellenModell: "+anzahl);
			return anzahl;
    	     } // if
			} // end of try

			catch(Exception ee) { 
// System.out.println("tabmodell exc = "+ee);			
			}
			return 0;		
		} // end of getRowCount

      /** Hilfsfunktion: gibt aktuellen Spaltennamen zur�ck
         *  @param int spalte
         *  @return String
         *  @exception
         */
        public String getColumnName(int col) {
        // wenn Index ausserhalb der Grenzen ist ->
        // nichts tun/ ignorieren bzw. leerer String
          if ((col<0) || (col>this.getColumnCount())) return new String("");
          return columnNames[col];
        } // end of getColumnName

      /** Hilfsfunktion: gibt String an den aktuellen Koordinaten zur�ck
         *  @param int reihe, int spalte
         *  @return Object
         *  @exception
         */
        public Object getValueAt(int row, int col) {
	      // aus aktuellem Ordner Sachen lesen ....
	      try {
	        // aktuellen Pfad rausfinden
    	    TreePath pfad=OrdnerOberflaeche.gibAktPfad();
	        // Vector auf Mailobjekte gewinnen
	        Vector mailVec=new Vector();
	        Object temp=OrdnerOberflaeche.gibAktuelleWurzelAlsObjekt().getPfadAlsVector(pfad).lastElement();
	        if(temp instanceof Ordner){
	           mailVec= ((Ordner)temp).gibAlleMails();
	           mailVec.trimToSize();
	         } // if


//    	    int anzahl=mailVec.size();
//System.out.println("row="+row);
// System.out.println("col="+col);
//System.out.println(mailVec.elementAt(row));
			switch(col) {
				case 0: return  ((Mail)mailVec.elementAt(row)).getSubject(); 
				case 1: return  Mail.adresseInString(((Mail)mailVec.elementAt(row)).getFrom());
				case 2: return  ((Mail)mailVec.elementAt(row)).datum;
				case 3: return  new Boolean(((Mail)mailVec.elementAt(row)).getStatus());
				} // end of switch
	      } // end of try

      catch(JTreeLaeuftNichtRichtig jlnr) {
//      System.out.println("TabellenModell -getValueAt "+jlnr);
      } // end of catch

      catch(KeineMailsDa kmd) {

//      System.out.println("TabellenModell -getValueAt "+kmd);
      } // end of catch

      catch(MessagingException mee) {
//      System.out.println("TabellenModell -getValueAt "+mee);
      } // end of catch

      catch(UngueltigerPfad up) {
//      System.out.println("TabellenModell -getValueAt "+up);
      } // end of catch
		return null;
		} // end of getValueAt

      /** Hilfsfunktion: zur Anzeige der letzten Spalte mit Checkbox
         *  @param int position
         *  @return Class
         *  @exception
         * JTable uses this method to determine the default renderer/
         * editor for each cell.  If we didn't implement this method,
         * then the last column would contain text ("true"/"false"),
         * rather than a check box.
         */
        public Class getColumnClass(int c) {
/*			switch(col) {
				case 0: return  "".getClass(); 
				case 1: return  (new InternetAddress()).getClass();
				case 2: return  new java.util.Date().getClass();
				case 3: return  (new Boolean()).getClass();
				} // end of switch
/*/            return (getValueAt(0, c) == null ? "".getClass() : getValueAt(0, c).getClass());
        }

  /** Hilfsfunktion: gibt das aktuelle markierte Mailobjekt zur�ck,
   *  sonst KeineMarkierungException
   *  @param aktuell selektierte Zeile aus Tabelle
   *  @return Mail
   *  @exception KeineMarkierung
   */
  public static Mail aktuelleMail(int selektierteZeile) throws KeineMarkierung {
      try {
        // aktuellen Pfad rausfinden
        TreePath pfad=(OrdnerOberflaeche).gibAktPfad();
        // Iterator auf Mailobjekte gewinnen
        Vector mailVec;
        Object temp=((OrdnerOberflaeche).gibAktuelleWurzelAlsObjekt()).getPfadAlsVector(pfad).lastElement();
        if(temp instanceof Ordner){
         mailVec= ((Ordner)temp).gibAlleMails();
        // vom Mailiterator, da� aktuelleSelektion.te ausw�hlen
//System.out.println("aktuelleMail = "+(mailVec.elementAt(selektierteZeile)));
//System.out.println("aktuelleMail SUBJECT = "+((Mail)(mailVec.elementAt(selektierteZeile))).datum);
        return ((Mail)(mailVec.elementAt(selektierteZeile)));
        } // if
	throw new JTreeLaeuftNichtRichtig();
      } // end of try

    // wenn die Exceptions kamen, war irgendwas faul!
      catch(JTreeLaeuftNichtRichtig jlnr) {
      throw new KeineMarkierung();
      } // end of catch

      catch(KeineMailsDa kmd) {
      throw new KeineMarkierung();
      } // end of catch

      catch(UngueltigerPfad up) {
      throw new KeineMarkierung();
      } // end of catch
  } // end of aktuelleMail
} // end of TabellenModell
