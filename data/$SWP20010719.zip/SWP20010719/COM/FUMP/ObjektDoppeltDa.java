package com.fump;
/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: ObjektDoppeltDa.java,v 1.1 2001/06/20 15:25:42 ottlinge Exp $
 */

    /** ObjektDoppeltDa-Exception
    */
public class ObjektDoppeltDa extends Exception { }
