package com.fump;
/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: KeineMailsDa.java,v 1.1 2001/06/20 15:25:41 ottlinge Exp $
 */

    /** KeineMailsDa-Exception
    */
public class KeineMailsDa extends Exception { }
