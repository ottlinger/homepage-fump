package com.fump.bearbeiten;

/**
*  @author Tobias Becker (tbecker), Joerg Dieckmann (dieck)
*  @version $Id: NeueMail.java,v 1.18 2001/07/18 17:02:18 tbecker Exp $
*
*
*/

import com.fump.bearbeiten.*;
import com.fump.pkonto.*;
import com.fump.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;

public class NeueMail extends JFrame //implements WindowListener
{
	/**
	 * Ein neuer MailGeschriebenListener soll implementiert werden
	 */
	private EventListenerList listenerList = new EventListenerList();
	private NeueMailGeschriebenEvent neueMailEvent = null;
	private WillAntwortMailSchreibenEvent antwortMailEvent = null;
	
	/**
	 * Die neuen Listener anmelden
	 */
	public synchronized void addNeueMailGeschriebenListener(NeueMailGeschriebenListener l)
	{
		listenerList.add(NeueMailGeschriebenListener.class,l);
	}
	
	public synchronized void addWillAntwortMailSchreibenListener(WillAntwortMailSchreibenListener l)
	{
		listenerList.add(WillAntwortMailSchreibenListener.class,l);
	}
	
	/**
	 * Die Listener wieder entfernen
	 */
	public synchronized void removeNeueMailGeschriebenListener(NeueMailGeschriebenListener l)
	{
		listenerList.remove(NeueMailGeschriebenListener.class,l);
	}
	
	public synchronized void removeWillAntwortMailSchreibenListener(NeueMailGeschriebenListener l)
	{
		listenerList.remove(WillAntwortMailSchreibenListener.class,l);
	}

	/**
	 * Abschicken eines NeueMailGeschriebenEvents
	 */
	protected void fireNeueMailGeschriebenEvent(String absender,String anAdressen, 
							String kopieAdressen,String blindKopieAdressen,String betreff, File[] anhaengsel)
	{
		Object[] listeners = listenerList.getListenerList();
		for (int i = listeners.length-2;i>=0;i-=2)
		{
			if (listeners[i] == NeueMailGeschriebenListener.class)
			{
				if (neueMailEvent == null)
				{
					neueMailEvent = new NeueMailGeschriebenEvent(this,absender,anAdressen,kopieAdressen,blindKopieAdressen,betreff,textPane.getText(),anhaengsel);
					//Toolkit toolkit = getToolkit (); 
					//EventQueue queue = toolkit.getSystemEventQueue (); 
                			//queue.postEvent (neueMailEvent); 
				}
				((NeueMailGeschriebenListener)listeners[i+1]).geschriebeneMailAbholen(neueMailEvent);
			}
		}
	}
	
	/**
	 * Abschicken eines WillAntwortMailSchreibenEvents
	 */
	protected void fireWillAntwortMailSchreibenEvent(String anAdressen,String kopieAdressen)
	{
		Object[] listeners = listenerList.getListenerList();
		for (int i = listeners.length-2;i>=0;i-=2)
		{
			if (listeners[i] == WillAntwortMailSchreibenListener.class)
			{
				if (antwortMailEvent == null)
				{
					antwortMailEvent = new WillAntwortMailSchreibenEvent(this,anAdressen,kopieAdressen,textPane.getText());
				}
				((WillAntwortMailSchreibenListener)listeners[i+1]).antwortMailSchreiben(antwortMailEvent);
			}
		}
	}
	
		
	private BorderLayout bl = new BorderLayout();
	public JEditorPane textPane = new JEditorPane();
	public Benutzer benutzer;

	/**
	 *Konstruktor um eine Mail zu schreiben 
	 */
	public NeueMail(Benutzer benutzer)
	{
		super("Neue Mail schreiben");
		setIconImage(Toolkit.getDefaultToolkit().createImage(FUMP.class.getResource("bilder/e-logo_21x21.GIF")));
		this.benutzer=benutzer;
		
		// Layout setzen
		getContentPane().setLayout(bl);
		
		// SchreibPanel hinzuf�gen
		SchreibPanel schreibPanel = new SchreibPanel(this,benutzer.gibKontoKontainer()/*,kontoContainer*/);
		getContentPane().add(schreibPanel,BorderLayout.NORTH);

		//Die Textfl�che initialisieren und hinzuf�gen
		getContentPane().add(new JScrollPane(textPane),BorderLayout.CENTER);
		
		//Fenster sichtbar machen
		setSize(500,500);
		show();
	}
	
		
	public NeueMail(Benutzer benutzer,WillAntwortMailSchreibenEvent e)
	{
		super("Sie wollen doch wohl nicht etwa eine Antwort schreiben???");
		
		// Layout setzen
		this.benutzer=benutzer;
		setIconImage(Toolkit.getDefaultToolkit().createImage(FUMP.class.getResource("bilder/e-logo_21x21.GIF")));
		getContentPane().setLayout(bl);
		
		// SchreibPanel hinzuf�gen
		SchreibPanel schreibPanel = new SchreibPanel(this,benutzer.gibKontoKontainer(),e.getEmpfaengerTo(), e.getEmpfaengerCC());
		getContentPane().add(schreibPanel,BorderLayout.NORTH);

		//Die Textfl�che initialisieren und hinzuf�gen
//		System.out.println(mailText);
//		System.out.println(antwortTextEinruecken(mailText));
		textPane.setText(antwortTextEinruecken(e.getMailText()));
		getContentPane().add(new JScrollPane(textPane),BorderLayout.CENTER);
		
		//Fenster sichtbar machen
		setSize(500,500);
		show();
	}

	/**
	 *Konstruktor zum testen
	 *nicht verwenden!!!!
	 */

	public NeueMail(Message nachricht)
	{
		super("Mail lesen");
		setIconImage(Toolkit.getDefaultToolkit().createImage(FUMP.class.getResource("bilder/e-logo_21x21.GIF")));
		this.benutzer=benutzer;
		
		// Layout setzen
		getContentPane().setLayout(bl);
		
		// LesePanel hinzuf�gen
		LesePanel lesePanel = new LesePanel(this, nachricht);
		getContentPane().add(lesePanel,BorderLayout.NORTH);
		System.out.println("lesepanel dazu");

		//Die Textfl�che initialisieren und hinzuf�gen
		textPane.setEditable(false);
		getContentPane().add(new JScrollPane(textPane),BorderLayout.CENTER);
		
		//Fenster sichtbar machen
		setSize(500,500);
		show();
	}

	public NeueMail(Message nachricht,boolean lesen)
	{
		super("Mail lesen");
		setIconImage(Toolkit.getDefaultToolkit().createImage(FUMP.class.getResource("bilder/e-logo_21x21.GIF")));
		this.benutzer=benutzer;
		
		// Layout setzen
		getContentPane().setLayout(bl);
		
		// LesePanel hinzuf�gen
		LesePanel lesePanel = new LesePanel(this, nachricht);
		getContentPane().add(lesePanel,BorderLayout.NORTH);
		System.out.println("lesepanel dazu");

		//Die Textfl�che initialisieren und hinzuf�gen
		textPane.setEditable(false);
		getContentPane().add(new JScrollPane(textPane),BorderLayout.CENTER);
		
		//Fenster sichtbar machen
		setSize(500,500);
		show();
	}
	
	
	public NeueMail(Benutzer benutzer, Message nachricht)
	{
		super("Mail lesen");
		setIconImage(Toolkit.getDefaultToolkit().createImage(FUMP.class.getResource("bilder/e-logo_21x21.GIF")));
		this.benutzer=benutzer;
		
		// Layout setzen
		getContentPane().setLayout(bl);
		
		// LesePanel hinzuf�gen
		LesePanel lesePanel = new LesePanel(this, nachricht);
		getContentPane().add(lesePanel,BorderLayout.NORTH);
//		System.out.println("lesepanel dazu");

		//Die Textfl�che initialisieren und hinzuf�gen
		textPane.setEditable(false);
		getContentPane().add(new JScrollPane(textPane),BorderLayout.CENTER);
		
		//Fenster sichtbar machen
		setSize(500,500);
		show();
	}

	
	/**
	 *
	 * Konstruktor um eine Mail zu beantworten oder zu lesen
	 * 
	 * @beantworten true nachricht wird zum Schreiben angezeigt
	 *				false die nachricht wird zum Lesen angezeigt
	 */ 
	public NeueMail(Benutzer benutzer, Message nachricht, boolean beantworten)
	{
		super("Mail lesen");
		setIconImage(Toolkit.getDefaultToolkit().createImage(FUMP.class.getResource("bilder/e-logo_21x21.GIF")));

		this.benutzer=benutzer;
		
		// Layout setzen
		getContentPane().setLayout(bl);
		
		// LesePanel hinzuf�gen
		if (beantworten) 
		{
			String f="";
			String ft ="";
			try{
				f = wandelAdresse(nachricht.getFrom());
			}catch(Exception x){;}
			try{
				ft = wandelAdresse(nachricht.getRecipients(Message.RecipientType.CC));
			}catch(Exception x){;}
				
			SchreibPanel schreibPanel = new SchreibPanel(this,benutzer.gibKontoKontainer(),f/*from*/,ft/*cc*/);
			getContentPane().add(schreibPanel,BorderLayout.NORTH);
			try
			{
				if (!(nachricht.isMimeType("text/plain")))
				{
					MimeMultipart mime;
					boolean gefunden = false;
				}
				else 
				{
					Object o = nachricht.getContent();
					if (o instanceof String)
					{
						String s=(String) o;
						textPane.setText(antwortTextEinruecken(s));
					}
				}
			}catch(Exception x){System.out.println("text nicht wandelbar" +x.toString());}
			textPane.setEditable(true);
		}
		else 
		{
			LesePanel lesePanel = new LesePanel(this, nachricht);
			getContentPane().add(lesePanel,BorderLayout.NORTH);
			textPane.setEditable(false);
		}

		//Die Textfl�che initialisieren und hinzuf�gen
		getContentPane().add(new JScrollPane(textPane),BorderLayout.CENTER);
		
		//Fenster sichtbar machen
		setSize(500,500);
		show();
	}
	
	private String wandelAdresse(Address[] adr)
	{
		String str = adr[0].toString();
		for(int i=1;i<adr.length;i++)
		{
			str+= ", " + adr[i].toString();
		}
		return str;
	}

	
	private String antwortTextEinruecken(String text)
	{
		int vorn=0;
		int hinten=0;
		String retur="\n";
		try
		{
			while((vorn=text.indexOf('\n',hinten))>=0)
			{
				retur+="> ";
				retur+=(text.substring(hinten,vorn-hinten));
				hinten = vorn+1;
			}
		}catch(Exception x){;}
		return retur;
	}


	// implements WindowListener
	public void windowActivated(WindowEvent e)
	{;}
	
	// implements WindowListener
	public void windowClosed(WindowEvent e)
	{
		dispose();
	}

	// implements WindowListener
	public void windowClosing(WindowEvent e)
	{;}
	
	// implements WindowListener
	public void windowDeactivated(WindowEvent e)
	{;}
	
	// implements WindowListener
	public void windowDeiconified(WindowEvent e)
	{;}
	
	// implements WindowListener
	public void windowIconified(WindowEvent e)
	{;}
	
	// implements WindowListener
	public void windowOpened(WindowEvent e)
	{;}
}

//wenn hilfe erforderlich
//FUMP.hilfe.kontext_hilfe("NeueMail");
