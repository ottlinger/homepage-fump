package com.fump.bearbeiten;

import java.util.*;
import com.fump.bearbeiten.*;

public interface AntwortMailGeschriebenListener extends EventListener
{
	public void antwortMailAbholen(NeueMailGeschriebenEvent e);
}
