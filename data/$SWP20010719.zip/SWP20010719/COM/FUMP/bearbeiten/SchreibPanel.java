package com.fump.bearbeiten;

/**
*  @author Tobias Becker (tbecker), Joerg Dieckmann (dieck)
*  @version $Id: SchreibPanel.java,v 1.13 2001/07/18 17:01:01 tbecker Exp $
*
*
*/

import com.fump.pkonto.*;
import com.fump.*;
import com.fump.bearbeiten.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;


public class SchreibPanel extends JPanel implements ActionListener
{
	private NeueMail mailFenster;
	private KontoContainer kontoContainer;
		
	private JButton abschickenKnopf;
	private JLabel absenderLabel;
	private JComboBox absenderFeld;
	private JTextField anAdressenFeld;
	private JLabel anLabel;
	private JTextField kopieAdressenFeld;
	private JLabel kopieLabel;
	private JTextField blindKopieAdressenFeld;
	private JLabel blindKopieLabel;
	private JButton adressbuchOeffnenAnKnopf;
	private JButton adressbuchOeffnenCCKnopf;
	private JButton adressbuchOeffnenBCCKnopf;
	private JLabel betreffLabel;
	private JTextField betreffFeld;
	private JLabel anhaengselLabel;
	private JComboBox anhaengselFeld;
	private JButton anhaengselKnopf;
	private boolean dateienEingefuegt=false;
	private Vector anhaengselDateien = new Vector();
	private GridBagLayout gbl = new GridBagLayout();


	
	
	public SchreibPanel(NeueMail neueMail)
	{
		// damit man bei dem ActionListener auf das TextFEld zugreifen kann
		mailFenster = neueMail;
		
		setLayout(gbl);
	
		absenderLabel = new JLabel("Absender:");
		addComponent(absenderLabel,0,0,1,1,0.0,0.0);		
		absenderFeld = new JComboBox();
		// hier muss die Methode zum Abrufen der
		// Absendernamen aufgerufen werden; sie soll einen Vector zur�ckgeben.	
		// ACHTUNG: am Schluss der Methode beim Mailschicken muss auf das selectedItem
		// der Combobox zur�ckgegriffen werden.
		addComponent(absenderFeld,1,0,0,1,1.0,0.0);
		
		anLabel = new JLabel("An:");
		addComponent(anLabel,0,1,1,1,0.0,0.0);
		anAdressenFeld = new JTextField();
		addComponent(anAdressenFeld,1,1,1,1,1.0,0.0);

		adressbuchOeffnenAnKnopf = new JButton (new ImageIcon(FUMP.class.getResource("bilder/e-adrbook_33x20.GIF")));/* hier muss das AdressbuchIcon hin */
		adressbuchOeffnenAnKnopf.addActionListener(this);
		addComponent(adressbuchOeffnenAnKnopf,2,1,1,1,0.0,0.0);
		
		kopieLabel = new JLabel("Kopie:");
		addComponent(kopieLabel,0,2,1,1,0.0,0.0);
		kopieAdressenFeld = new JTextField();
		addComponent(kopieAdressenFeld,1,2,1,1,1.0,0.0);
		
		adressbuchOeffnenCCKnopf = new JButton (new ImageIcon(FUMP.class.getResource("bilder/e-adrbook_33x20.GIF")));/* hier muss das AdressbuchIcon hin */
		adressbuchOeffnenCCKnopf.addActionListener(this);
		addComponent(adressbuchOeffnenCCKnopf,2,2,1,1,0.0,0.0);

		blindKopieLabel = new JLabel("Blindkopie:");
		addComponent(blindKopieLabel,0,3,1,1,0.0,0.0);
		blindKopieAdressenFeld = new JTextField();
		addComponent(blindKopieAdressenFeld,1,3,1,1,1.0,0.0);
		
		adressbuchOeffnenBCCKnopf = new JButton(new ImageIcon(FUMP.class.getResource("bilder/e-adrbook_33x20.GIF")));/*hier muss das AdressbuchIcon hin */
		adressbuchOeffnenBCCKnopf.addActionListener(this);
		addComponent(adressbuchOeffnenBCCKnopf,2,3,1,1,0.0,0.0);

		betreffLabel = new JLabel("Betreff");
		addComponent(betreffLabel,0,4,1,1,0.0,0.0);
		betreffFeld = new JTextField();
		addComponent(betreffFeld,1,4,0,1,1.0,0.0);
		
		anhaengselLabel = new JLabel("Anh�ngsel:");
		addComponent(anhaengselLabel,0,5,1,1,0.0,0.0);
		anhaengselFeld = new JComboBox();
		addComponent(anhaengselFeld,1,5,1,1,1.0,0.0);
		anhaengselFeld.addActionListener(this);
		
		anhaengselKnopf = new JButton(new ImageIcon(FUMP.class.getResource("bilder/e-attachment_50x30.GIF")));
		addComponent(anhaengselKnopf,2,5,1,1,0.0,0.0);
		anhaengselKnopf.addActionListener(this);
		
		abschickenKnopf = new JButton("Senden"/*,new ImageIcon("hier kommt der Bildname rein"*/);
		abschickenKnopf.addActionListener(this);
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.insets = new Insets(5,5,5,5);
			gbc.ipadx = 2; gbc.ipady = 2;
			gbc.fill = gbc.NONE;
			gbc.anchor = gbc.CENTER;
			gbc.gridx = 0; gbc.gridy=6;
			gbc.gridwidth = gbc.REMAINDER; gbc.gridheight = 1;
			gbc.weightx = 0.0; gbc.weighty = 0.0;
			gbl.setConstraints(abschickenKnopf,gbc);
			add(abschickenKnopf);
	}
	
	public SchreibPanel(NeueMail neueMail,KontoContainer kontoContainer,String adresse,String adressecc)
	{
		this(neueMail);
		this.kontoContainer=kontoContainer;
		anAdressenFeld.setText(adresse);
		kopieAdressenFeld.setText(adressecc);
		Vector adr = kontoContainer.gibAbsenderBitte();
		if (adr==null) System.out.println("leider null");
		else 
		{
			for (int i= 0;i<adr.size();i++)
			{
				absenderFeld.addItem((String) adr.elementAt(i));
			}
		}
	}
	
	public SchreibPanel(NeueMail neueMail,KontoContainer kontoContainer)
	{
		this(neueMail);
		this.kontoContainer=kontoContainer;
		Vector adr = kontoContainer.gibAbsenderBitte();
		if (adr==null) System.out.println("leider null");
		else 
		{
			for (int i= 0;i<adr.size();i++)
			{
				absenderFeld.addItem(adr.elementAt(i));
			}
		}
	}
	
	private void addComponent(Component c,int x,int y,int width,int height,double weightx,double weighty)
	{
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(5,5,5,5);
		gbc.ipadx = 2; gbc.ipady = 2;
		gbc.fill = gbc.BOTH;
		gbc.gridx = x; gbc.gridy=y;
		gbc.gridwidth = width; gbc.gridheight = height;
		gbc.weightx = weightx; gbc.weighty = weighty;
		gbl.setConstraints(c,gbc);
		add(c);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == adressbuchOeffnenAnKnopf)
		{
			if (mailFenster.benutzer==null) System.out.println("benutzer: dev/null");
			Adressbuch adressbuch = mailFenster.benutzer.gibAdressbuch();
			if (adressbuch == null) System.out.println("nichts mit Adressbuch");
			adressbuch.setAdressenArt(1);
			adressbuch.pack();
			adressbuch.show();
			adressbuch.addAdressbuchListener(new AdressbuchListener() {
				public void adresseAbholen(AdressbuchEvent a)
				{
					if (a.getAdressenArt()==1)
					{
						if (anAdressenFeld.getText().equals("")) 	
						{
							anAdressenFeld.setText(a.getAdressen());
						}
						else 
						{
							anAdressenFeld.setText(anAdressenFeld.getText()+", "+a.getAdressen());
						}
					}
				}
			});
		}
		else if (e.getSource() == adressbuchOeffnenCCKnopf)
		{
			if (mailFenster.benutzer==null) System.out.println("benutzer: dev/null");
			Adressbuch adressbuch = mailFenster.benutzer.gibAdressbuch();
			if (adressbuch == null) System.out.println("nichts mit Adressbuch");
			adressbuch.setAdressenArt(2);
			adressbuch.pack();
			adressbuch.show();
			adressbuch.addAdressbuchListener(new AdressbuchListener() {
				public void adresseAbholen(AdressbuchEvent a)
				{
					if (a.getAdressenArt()==2)
					{
						if (kopieAdressenFeld.getText().equals("")) 	
						{
							kopieAdressenFeld.setText(a.getAdressen());
						}
						else 
						{
							kopieAdressenFeld.setText(kopieAdressenFeld.getText()+", "+a.getAdressen());
						}
					}
				}
			});
		}
		else if (e.getSource() == adressbuchOeffnenBCCKnopf)
		{
			if (mailFenster.benutzer==null) System.out.println("benutzer: dev/null");
			Adressbuch adressbuch = mailFenster.benutzer.gibAdressbuch();
			if (adressbuch == null) System.out.println("nichts mit Adressbuch");
			adressbuch.setAdressenArt(3);
			adressbuch.pack();
			adressbuch.show();
			adressbuch.addAdressbuchListener(new AdressbuchListener() {
				public void adresseAbholen(AdressbuchEvent a)
				{
					if (a.getAdressenArt()==3)
					{
						if (blindKopieAdressenFeld.getText().equals("")) 	
						{
							blindKopieAdressenFeld.setText(a.getAdressen());
						}
						else 
						{
							blindKopieAdressenFeld.setText(blindKopieAdressenFeld.getText()+", "+a.getAdressen());
						}
					}
				}
			});
		}
		else if (e.getSource() == abschickenKnopf)
		{
			//System.out.println("test");
			if (!(anAdressenFeld.getText().equals("")))
			{
				File[] f = new File[anhaengselDateien.size()];
				if (anhaengselDateien.size()==0) mailFenster.fireNeueMailGeschriebenEvent((String) absenderFeld.getSelectedItem(),anAdressenFeld.getText(),kopieAdressenFeld.getText(),blindKopieAdressenFeld.getText(),betreffFeld.getText(),null);
				else mailFenster.fireNeueMailGeschriebenEvent((String) absenderFeld.getSelectedItem(),anAdressenFeld.getText(),kopieAdressenFeld.getText(),blindKopieAdressenFeld.getText(),betreffFeld.getText(),(File[]) anhaengselDateien.toArray(f));
				//for (int i=0;i<f.length;i++) System.out.println(f[i].toString());
					
			} 
			mailFenster.dispose();
		}
		else if (e.getSource() == anhaengselKnopf)
		{
			JFileChooser anhaengselDialog = new JFileChooser();
			anhaengselDialog.setMultiSelectionEnabled(true);
			int ergebnis = anhaengselDialog.showOpenDialog(mailFenster);
			if (ergebnis == JFileChooser.APPROVE_OPTION) 
			{
				File[] neueDateien = anhaengselDialog.getSelectedFiles();
				dateienEingefuegt = true;
				for (int i=0;i<neueDateien.length;i++)
				{
					anhaengselDateien.add(neueDateien[i]);
					anhaengselFeld.addItem(neueDateien[i].getName());
				}
			}
		}
		else if (e.getSource() == anhaengselFeld)
		{
			int index = anhaengselFeld.getSelectedIndex();
			System.out.println("action "+index);
			if (index>=0)
			{
				if (!dateienEingefuegt)
				{
					String[] option = {"Ja","Nein"};
					int ergebnis1 = JOptionPane.showOptionDialog(mailFenster,"Moechten Sie das Attachment wirklich nicht mitsenden?","Eine kurze Frage haette ich:",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,option,option[0]);
					if (ergebnis1 == JOptionPane.YES_OPTION)
					{
						anhaengselDateien.remove(index);
						anhaengselFeld.removeItemAt(index);
					}
				}else dateienEingefuegt=false;
			}
		}
	}	
}


