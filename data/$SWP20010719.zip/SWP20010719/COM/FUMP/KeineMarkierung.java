package com.fump;
/**
 * @author Markus Hindorf / Philipp Ottlinger
 * @version $Id: KeineMarkierung.java,v 1.1 2001/06/20 15:25:41 ottlinge Exp $
 */

    /** KeineMarkierung-Exception
    */
public class KeineMarkierung extends Exception { }
